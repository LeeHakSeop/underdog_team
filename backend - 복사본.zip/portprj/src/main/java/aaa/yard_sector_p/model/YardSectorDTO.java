package aaa.yard_sector_p.model;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class YardSectorDTO {

    // 기존 야드섹터 기본 정보
    private Long sectorId;
    private String sectorName;
    private String blockName;
    private String sectorStatus;
    private Integer waitingVehicleCount;
    private String guideMessage;
    private String altWaitingArea;

    // 야드섹터 업무 분류 및 운영 조건
    private String sectorCategory;
    private Integer sectorPriority;
    private BigDecimal maxVehicleWeightTon;
    private Boolean reeferPowerAvailable;
    private Boolean dangerousGoodsAllowed;
    private Boolean oogAllowed;
    private Boolean heavyCargoAllowed;
}