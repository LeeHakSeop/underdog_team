package aaa.yard_sector_p.model;

import java.math.BigDecimal;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface YardSectorMapper {

    /**
     * 전체 야드섹터 조회
     */
    @Select("""
            SELECT
                sector_id AS sectorId,
                sector_name AS sectorName,
                block_name AS blockName,
                sector_status AS sectorStatus,
                waiting_vehicle_count AS waitingVehicleCount,
                guide_message AS guideMessage,
                alt_waiting_area AS altWaitingArea,
                sector_category AS sectorCategory,
                sector_priority AS sectorPriority,
                max_vehicle_weight_ton AS maxVehicleWeightTon,
                reefer_power_available AS reeferPowerAvailable,
                dangerous_goods_allowed AS dangerousGoodsAllowed,
                oog_allowed AS oogAllowed,
                heavy_cargo_allowed AS heavyCargoAllowed
            FROM yard_sector
            ORDER BY sector_id
            """)
    List<YardSectorDTO> list();

    /**
     * 섹터 ID로 상세 조회
     */
    @Select("""
            SELECT
                sector_id AS sectorId,
                sector_name AS sectorName,
                block_name AS blockName,
                sector_status AS sectorStatus,
                waiting_vehicle_count AS waitingVehicleCount,
                guide_message AS guideMessage,
                alt_waiting_area AS altWaitingArea,
                sector_category AS sectorCategory,
                sector_priority AS sectorPriority,
                max_vehicle_weight_ton AS maxVehicleWeightTon,
                reefer_power_available AS reeferPowerAvailable,
                dangerous_goods_allowed AS dangerousGoodsAllowed,
                oog_allowed AS oogAllowed,
                heavy_cargo_allowed AS heavyCargoAllowed
            FROM yard_sector
            WHERE sector_id = #{sectorId}
            """)
    YardSectorDTO detail(
            @Param("sectorId") Long sectorId
    );

    /**
     * 섹터명으로 조회
     */
    @Select("""
            SELECT
                sector_id AS sectorId,
                sector_name AS sectorName,
                block_name AS blockName,
                sector_status AS sectorStatus,
                waiting_vehicle_count AS waitingVehicleCount,
                guide_message AS guideMessage,
                alt_waiting_area AS altWaitingArea,
                sector_category AS sectorCategory,
                sector_priority AS sectorPriority,
                max_vehicle_weight_ton AS maxVehicleWeightTon,
                reefer_power_available AS reeferPowerAvailable,
                dangerous_goods_allowed AS dangerousGoodsAllowed,
                oog_allowed AS oogAllowed,
                heavy_cargo_allowed AS heavyCargoAllowed
            FROM yard_sector
            WHERE sector_name = #{sectorName}
            """)
    YardSectorDTO findBySectorName(
            @Param("sectorName") String sectorName
    );

    /**
     * 야드 업무분류별 섹터 목록 조회
     */
    @Select("""
            SELECT
                sector_id AS sectorId,
                sector_name AS sectorName,
                block_name AS blockName,
                sector_status AS sectorStatus,
                waiting_vehicle_count AS waitingVehicleCount,
                guide_message AS guideMessage,
                alt_waiting_area AS altWaitingArea,
                sector_category AS sectorCategory,
                sector_priority AS sectorPriority,
                max_vehicle_weight_ton AS maxVehicleWeightTon,
                reefer_power_available AS reeferPowerAvailable,
                dangerous_goods_allowed AS dangerousGoodsAllowed,
                oog_allowed AS oogAllowed,
                heavy_cargo_allowed AS heavyCargoAllowed
            FROM yard_sector
            WHERE sector_category = #{sectorCategory}
            ORDER BY
                waiting_vehicle_count ASC NULLS FIRST,
                sector_priority ASC NULLS LAST,
                sector_name ASC
            """)
    List<YardSectorDTO> findByCategory(
            @Param("sectorCategory") String sectorCategory
    );

    /**
     * 차량·컨테이너 조건을 충족하는 사용 가능한 섹터 1개 추천
     */
    @Select("""
            SELECT
                sector_id AS sectorId,
                sector_name AS sectorName,
                block_name AS blockName,
                sector_status AS sectorStatus,
                waiting_vehicle_count AS waitingVehicleCount,
                guide_message AS guideMessage,
                alt_waiting_area AS altWaitingArea,
                sector_category AS sectorCategory,
                sector_priority AS sectorPriority,
                max_vehicle_weight_ton AS maxVehicleWeightTon,
                reefer_power_available AS reeferPowerAvailable,
                dangerous_goods_allowed AS dangerousGoodsAllowed,
                oog_allowed AS oogAllowed,
                heavy_cargo_allowed AS heavyCargoAllowed
            FROM yard_sector
            WHERE sector_category = #{sectorCategory}
              AND sector_status = '사용가능'
              AND (
                    CAST(#{grossWeightTon} AS NUMERIC) IS NULL
                    OR max_vehicle_weight_ton IS NULL
                    OR max_vehicle_weight_ton >= CAST(#{grossWeightTon} AS NUMERIC)
              )
              AND (
                    CAST(#{requiresReeferPower} AS BOOLEAN) = FALSE
                    OR reefer_power_available = TRUE
              )
              AND (
                    CAST(#{requiresDangerousGoods} AS BOOLEAN) = FALSE
                    OR dangerous_goods_allowed = TRUE
              )
              AND (
                    CAST(#{requiresOog} AS BOOLEAN) = FALSE
                    OR oog_allowed = TRUE
              )
              AND (
                    CAST(#{requiresHeavyCargo} AS BOOLEAN) = FALSE
                    OR heavy_cargo_allowed = TRUE
              )
            ORDER BY
                waiting_vehicle_count ASC NULLS FIRST,
                sector_priority ASC NULLS LAST,
                sector_name ASC
            LIMIT 1
            """)
    YardSectorDTO findRecommendedSector(
            @Param("sectorCategory") String sectorCategory,
            @Param("grossWeightTon") BigDecimal grossWeightTon,
            @Param("requiresReeferPower") boolean requiresReeferPower,
            @Param("requiresDangerousGoods") boolean requiresDangerousGoods,
            @Param("requiresOog") boolean requiresOog,
            @Param("requiresHeavyCargo") boolean requiresHeavyCargo
    );

    /**
     * 배정 시 대기 차량 수 증가
     */
    @Update("""
            UPDATE yard_sector
            SET waiting_vehicle_count =
                COALESCE(waiting_vehicle_count, 0) + 1
            WHERE sector_id = #{sectorId}
            """)
    int increaseWaitingVehicleCount(
            @Param("sectorId") Long sectorId
    );

    /**
     * 작업 완료·배정 취소 시 대기 차량 수 감소
     */
    @Update("""
            UPDATE yard_sector
            SET waiting_vehicle_count =
                GREATEST(COALESCE(waiting_vehicle_count, 0) - 1, 0)
            WHERE sector_id = #{sectorId}
            """)
    int decreaseWaitingVehicleCount(
            @Param("sectorId") Long sectorId
    );

    /**
     * 섹터 운영상태와 안내문구 수정
     */
    @Update("""
            UPDATE yard_sector
            SET
                sector_status = #{sectorStatus},
                guide_message = #{guideMessage},
                alt_waiting_area = #{altWaitingArea}
            WHERE sector_id = #{sectorId}
            """)
    int updateOperationStatus(
            @Param("sectorId") Long sectorId,
            @Param("sectorStatus") String sectorStatus,
            @Param("guideMessage") String guideMessage,
            @Param("altWaitingArea") String altWaitingArea
    );

    /**
     * 섹터 업무분류와 허용조건 수정
     */
    @Update("""
            UPDATE yard_sector
            SET
                sector_category = #{sectorCategory},
                sector_priority = #{sectorPriority},
                max_vehicle_weight_ton = #{maxVehicleWeightTon},
                reefer_power_available =
                    COALESCE(#{reeferPowerAvailable}, FALSE),
                dangerous_goods_allowed =
                    COALESCE(#{dangerousGoodsAllowed}, FALSE),
                oog_allowed =
                    COALESCE(#{oogAllowed}, FALSE),
                heavy_cargo_allowed =
                    COALESCE(#{heavyCargoAllowed}, FALSE)
            WHERE sector_id = #{sectorId}
            """)
    int updateClassification(YardSectorDTO dto);
}