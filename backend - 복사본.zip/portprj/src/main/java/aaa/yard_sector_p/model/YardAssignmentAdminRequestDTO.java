package aaa.yard_sector_p.model;

import lombok.Data;

/**
 * 관리자 야드배정 처리 요청 DTO 모음.
 *
 * WBS 9-3:
 * 1. AI 추천 승인
 * 2. 수동 섹터 변경
 * 3. 검사 보류 처리
 */
public final class YardAssignmentAdminRequestDTO {

    private YardAssignmentAdminRequestDTO() {
    }

    @Data
    public static class ApproveRequest {
        private Long workOrderId;
    }

    @Data
    public static class ManualAssignRequest {
        private Long workOrderId;
        private Long sectorId;
        private String reason;
    }

    @Data
    public static class InspectionHoldRequest {
        private Long workOrderId;
        private String reason;
    }
}