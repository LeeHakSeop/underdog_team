package aaa.yard_sector_p.model;

import lombok.Data;

@Data
public class YardAssignmentResultDTO {

    private Boolean success;
    private String message;

    private String plateNumber;

    private Long vehicleId;
    private String vehicleType;
    private String vehicleStructure;
    private Integer axleCount;

    private Long workOrderId;
    private Long containerId;
    private String containerNumber;
    private String containerType;

    private String sectorCategory;
    private Long assignedSectorId;
    private String assignedSectorName;

    private String assignmentReason;
    private String assignmentMethod;
}