package aaa.yard_sector_p.service;

import aaa.container_p.model.ContainerDTO;
import aaa.container_p.model.ContainerMapper;
import aaa.vehicle_p.model.VehicleDTO;
import aaa.vehicle_p.model.VehicleMapper;
import aaa.work_order_p.model.WorkOrderDTO;
import aaa.work_order_p.model.WorkOrderMapper;
import aaa.yard_sector_p.model.YardAssignmentAdminRequestDTO.ApproveRequest;
import aaa.yard_sector_p.model.YardAssignmentAdminRequestDTO.InspectionHoldRequest;
import aaa.yard_sector_p.model.YardAssignmentAdminRequestDTO.ManualAssignRequest;
import aaa.yard_sector_p.model.YardAssignmentResultDTO;
import aaa.yard_sector_p.model.YardSectorDTO;
import aaa.yard_sector_p.model.YardSectorMapper;
import jakarta.annotation.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class YardAssignmentService {

    private static final String METHOD_AUTO_RECOMMENDED = "AUTO_RECOMMENDED";
    private static final String METHOD_ADMIN_APPROVED = "ADMIN_APPROVED";
    private static final String METHOD_MANUAL = "MANUAL";

    @Resource
    private VehicleMapper vehicleMapper;

    @Resource
    private WorkOrderMapper workOrderMapper;

    @Resource
    private ContainerMapper containerMapper;

    @Resource
    private YardSectorMapper yardSectorMapper;

    /**
     * OCR로 인식된 번호판을 기준으로 차량, 활성 작업지시, 컨테이너 정보를 조회한 뒤
     * 적합한 야드섹터를 추천하고 work_order에 저장한다.
     *
     * 동일 작업지시를 반복 조회할 때는 대기 차량 수를 중복 증가시키지 않는다.
     * 기존 배정과 새 배정이 다르면 기존 섹터는 -1, 새 섹터는 +1 처리한다.
     */
    @Transactional
    public YardAssignmentResultDTO recommendByPlateNumber(String plateNumber) {
        String normalizedPlateNumber = normalizePlateNumber(plateNumber);

        VehicleDTO vehicle = vehicleMapper.findByPlateNumber(normalizedPlateNumber);
        if (vehicle == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "등록된 차량을 찾을 수 없습니다: " + normalizedPlateNumber
            );
        }

        if (!Boolean.TRUE.equals(vehicle.getIsRegistered())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "관리자 승인이 완료되지 않은 차량입니다."
            );
        }

        WorkOrderDTO workOrder =
                workOrderMapper.findActiveByVehicleId(vehicle.getVehicleId());

        if (workOrder == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "해당 차량의 활성 작업지시를 찾을 수 없습니다."
            );
        }

        if (workOrder.getContainerId() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "작업지시에 컨테이너가 연결되어 있지 않습니다."
            );
        }

        ContainerDTO container =
                containerMapper.detail(workOrder.getContainerId());

        if (container == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "작업지시에 연결된 컨테이너를 찾을 수 없습니다."
            );
        }

        String sectorCategory =
                determineSectorCategory(vehicle, container);

        String assignmentReason =
                buildAssignmentReason(vehicle, sectorCategory);

        YardSectorDTO recommendedSector =
                yardSectorMapper.findRecommendedSector(
                        sectorCategory,
                        vehicle.getGrossWeightTon(),
                        Boolean.TRUE.equals(container.getReefer()),
                        Boolean.TRUE.equals(container.getDangerousGoods()),
                        Boolean.TRUE.equals(container.getOog()),
                        Boolean.TRUE.equals(container.getHeavyCargo())
                );

        if (recommendedSector == null) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "조건에 맞는 사용 가능한 야드섹터가 없습니다."
            );
        }

        Long previousSectorId = workOrder.getAssignedSectorId();
        Long newSectorId = recommendedSector.getSectorId();

        int updated = workOrderMapper.updateAssignment(
                workOrder.getWorkOrderId(),
                newSectorId,
                assignmentReason,
                METHOD_AUTO_RECOMMENDED
        );

        if (updated == 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "야드섹터 배정 결과를 저장하지 못했습니다."
            );
        }

        String resultMessage;

        if (previousSectorId == null) {
            yardSectorMapper.increaseWaitingVehicleCount(newSectorId);
            resultMessage = "야드섹터 추천이 완료되었습니다.";
        } else if (previousSectorId.equals(newSectorId)) {
            resultMessage = "기존 추천 섹터와 동일하여 대기 차량 수는 변경하지 않았습니다.";
        } else {
            yardSectorMapper.decreaseWaitingVehicleCount(previousSectorId);
            yardSectorMapper.increaseWaitingVehicleCount(newSectorId);
            resultMessage = "야드섹터가 새 조건에 맞게 재배정되었습니다.";
        }

        return buildResult(
                normalizedPlateNumber,
                vehicle,
                workOrder,
                container,
                recommendedSector,
                assignmentReason,
                resultMessage
        );
    }


    /**
     * AI가 추천한 현재 섹터를 관리자가 최종 승인한다.
     * 섹터가 바뀌지 않으므로 waiting_vehicle_count는 변경하지 않는다.
     */
    @Transactional
    public YardAssignmentResultDTO approveRecommendation(ApproveRequest request) {
        Long workOrderId = requireWorkOrderId(
                request == null ? null : request.getWorkOrderId()
        );

        WorkOrderDTO workOrder = requireWorkOrder(workOrderId);
        Long assignedSectorId = workOrder.getAssignedSectorId();

        if (assignedSectorId == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "승인할 AI 추천 섹터가 없습니다."
            );
        }

        YardSectorDTO sector = requireSector(assignedSectorId);
        String reason = normalizeReason(
                workOrder.getAssignmentReason(),
                "AI 추천 결과를 관리자가 최종 승인"
        );

        int updated = workOrderMapper.updateAssignment(
                workOrderId,
                assignedSectorId,
                reason,
                METHOD_ADMIN_APPROVED
        );

        if (updated == 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "AI 추천 승인 결과를 저장하지 못했습니다."
            );
        }

        return buildAdminResult(
                workOrder,
                sector,
                reason,
                METHOD_ADMIN_APPROVED,
                "AI 추천 섹터를 최종 승인했습니다."
        );
    }

    /**
     * 관리자가 원하는 섹터를 직접 지정한다.
     *
     * 기존 섹터와 동일하면 대기 차량 수를 변경하지 않고,
     * 기존 섹터와 다르면 기존 -1 / 신규 +1 처리한다.
     */
    @Transactional
    public YardAssignmentResultDTO assignManually(ManualAssignRequest request) {
        if (request == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "수동 배정 요청값이 없습니다."
            );
        }

        Long workOrderId = requireWorkOrderId(request.getWorkOrderId());

        if (request.getSectorId() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "수동 배정할 야드섹터를 선택하세요."
            );
        }

        WorkOrderDTO workOrder = requireWorkOrder(workOrderId);
        YardSectorDTO newSector = requireSector(request.getSectorId());

        if (!isSectorAvailable(newSector)) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "현재 사용할 수 없는 야드섹터입니다."
            );
        }

        Long previousSectorId = workOrder.getAssignedSectorId();
        Long newSectorId = newSector.getSectorId();
        String reason = normalizeReason(
                request.getReason(),
                "관리자 수동 야드섹터 지정"
        );

        int updated = workOrderMapper.updateAssignment(
                workOrderId,
                newSectorId,
                reason,
                METHOD_MANUAL
        );

        if (updated == 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "수동 야드배정 결과를 저장하지 못했습니다."
            );
        }

        updateWaitingVehicleCount(previousSectorId, newSectorId);

        return buildAdminResult(
                workOrder,
                newSector,
                reason,
                METHOD_MANUAL,
                previousSectorId != null && previousSectorId.equals(newSectorId)
                        ? "기존 섹터와 동일한 섹터로 수동 확정했습니다."
                        : "관리자가 야드섹터를 수동 변경했습니다."
        );
    }

    /**
     * 작업지시를 검사·보류 섹터로 이동시킨다.
     */
    @Transactional
    public YardAssignmentResultDTO holdForInspection(
            InspectionHoldRequest request
    ) {
        if (request == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "검사 보류 요청값이 없습니다."
            );
        }

        Long workOrderId = requireWorkOrderId(request.getWorkOrderId());
        WorkOrderDTO workOrder = requireWorkOrder(workOrderId);

        YardSectorDTO inspectionSector =
                yardSectorMapper.findRecommendedSector(
                        "INSPECTION_HOLD",
                        null,
                        false,
                        false,
                        false,
                        false
                );

        if (inspectionSector == null) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "사용 가능한 검사·보류 섹터가 없습니다."
            );
        }

        String reason = normalizeReason(
                request.getReason(),
                "관리자 검사·보류 처리"
        );

        Long previousSectorId = workOrder.getAssignedSectorId();
        Long newSectorId = inspectionSector.getSectorId();

        int updated = workOrderMapper.updateAssignment(
                workOrderId,
                newSectorId,
                reason,
                METHOD_MANUAL
        );

        if (updated == 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "검사·보류 결과를 저장하지 못했습니다."
            );
        }

        updateWaitingVehicleCount(previousSectorId, newSectorId);

        return buildAdminResult(
                workOrder,
                inspectionSector,
                reason,
                METHOD_MANUAL,
                "작업지시를 검사·보류 섹터로 이동했습니다."
        );
    }

    private Long requireWorkOrderId(Long workOrderId) {
        if (workOrderId == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "작업지시 ID가 필요합니다."
            );
        }

        return workOrderId;
    }

    private WorkOrderDTO requireWorkOrder(Long workOrderId) {
        WorkOrderDTO workOrder = workOrderMapper.detail(workOrderId);

        if (workOrder == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "작업지시를 찾을 수 없습니다: " + workOrderId
            );
        }

        return workOrder;
    }

    private YardSectorDTO requireSector(Long sectorId) {
        YardSectorDTO sector = yardSectorMapper.detail(sectorId);

        if (sector == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "야드섹터를 찾을 수 없습니다: " + sectorId
            );
        }

        return sector;
    }

    private boolean isSectorAvailable(YardSectorDTO sector) {
        String status = sector.getSectorStatus();

        return status == null
                || status.isBlank()
                || "사용가능".equals(status)
                || "AVAILABLE".equalsIgnoreCase(status)
                || "NORMAL".equalsIgnoreCase(status);
    }

    private String normalizeReason(String reason, String defaultReason) {
        if (reason == null || reason.isBlank()) {
            return defaultReason;
        }

        return reason.trim();
    }

    private void updateWaitingVehicleCount(
            Long previousSectorId,
            Long newSectorId
    ) {
        if (newSectorId == null) {
            return;
        }

        if (previousSectorId == null) {
            yardSectorMapper.increaseWaitingVehicleCount(newSectorId);
            return;
        }

        if (previousSectorId.equals(newSectorId)) {
            return;
        }

        yardSectorMapper.decreaseWaitingVehicleCount(previousSectorId);
        yardSectorMapper.increaseWaitingVehicleCount(newSectorId);
    }

    private YardAssignmentResultDTO buildAdminResult(
            WorkOrderDTO workOrder,
            YardSectorDTO sector,
            String assignmentReason,
            String assignmentMethod,
            String message
    ) {
        ContainerDTO container = workOrder.getContainerId() == null
                ? null
                : containerMapper.detail(workOrder.getContainerId());

        YardAssignmentResultDTO result = new YardAssignmentResultDTO();

        result.setSuccess(true);
        result.setMessage(message);
        result.setWorkOrderId(workOrder.getWorkOrderId());

        if (container != null) {
            result.setContainerId(container.getContainerId());
            result.setContainerNumber(container.getContainerNumber());
            result.setContainerType(container.getContainerType());
        }

        result.setSectorCategory(sector.getSectorCategory());
        result.setAssignedSectorId(sector.getSectorId());
        result.setAssignedSectorName(sector.getSectorName());
        result.setAssignmentReason(assignmentReason);
        result.setAssignmentMethod(assignmentMethod);

        return result;
    }

    /**
     * 컨테이너 특성과 차량 검증 조건을 기준으로 야드 업무분류를 결정한다.
     * 우선순위:
     * 검사·계근 → 위험물 → OOG → 중량물 → 냉동 → 파손
     * → 공컨테이너 → 수입 적컨테이너 → 수출 적컨테이너 → 일반화물
     */
    private String determineSectorCategory(
            VehicleDTO vehicle,
            ContainerDTO container
    ) {
        if (Boolean.TRUE.equals(container.getInspectionRequired())
                || Boolean.TRUE.equals(vehicle.getRequiresWeighing())
                || hasHoldStatus(container)) {
            return "INSPECTION_HOLD";
        }

        if (Boolean.TRUE.equals(container.getDangerousGoods())) {
            return "DANGEROUS_GOODS";
        }

        if (Boolean.TRUE.equals(container.getOog())) {
            return "OOG";
        }

        if (Boolean.TRUE.equals(container.getHeavyCargo())
                || Boolean.TRUE.equals(vehicle.getSpecialTransport())) {
            return "HEAVY_CARGO";
        }

        if (Boolean.TRUE.equals(container.getReefer())) {
            return "REEFER";
        }

        if (Boolean.TRUE.equals(container.getDamaged())) {
            return "DAMAGE_RESERVE";
        }

        if ("EMPTY".equalsIgnoreCase(container.getLoadStatus())) {
            return "EMPTY";
        }

        if ("IMPORT".equalsIgnoreCase(container.getCargoFlowType())
                && "FULL".equalsIgnoreCase(container.getLoadStatus())) {
            return "IMPORT_FULL";
        }

        if ("EXPORT".equalsIgnoreCase(container.getCargoFlowType())
                && "FULL".equalsIgnoreCase(container.getLoadStatus())) {
            return "EXPORT_FULL";
        }

        return "GENERAL_CARGO";
    }

    private boolean hasHoldStatus(ContainerDTO container) {
        String holdStatus = container.getHoldStatus();

        return holdStatus != null
                && !holdStatus.isBlank()
                && !"NONE".equalsIgnoreCase(holdStatus)
                && !"NORMAL".equalsIgnoreCase(holdStatus);
    }

    private String buildAssignmentReason(
            VehicleDTO vehicle,
            String sectorCategory
    ) {
        return switch (sectorCategory) {
            case "INSPECTION_HOLD" ->
                    Boolean.TRUE.equals(vehicle.getRequiresWeighing())
                            ? "차량 계근 또는 관리자 확인이 필요한 작업"
                            : "컨테이너 검사·보류 조건 적용";

            case "DANGEROUS_GOODS" ->
                    "위험물 컨테이너 전용 섹터 배정";

            case "OOG" ->
                    "초과규격(OOG) 컨테이너 전용 섹터 배정";

            case "HEAVY_CARGO" ->
                    "중량물 또는 특수운송 조건 적용";

            case "REEFER" ->
                    "냉동 전원 사용 가능한 섹터 배정";

            case "DAMAGE_RESERVE" ->
                    "파손 컨테이너 검사·예비 섹터 배정";

            case "EMPTY" ->
                    "공컨테이너 전용 섹터 배정";

            case "IMPORT_FULL" ->
                    "수입 적컨테이너 전용 섹터 배정";

            case "EXPORT_FULL" ->
                    "수출 적컨테이너 전용 섹터 배정";

            default ->
                    "일반화물·CFS 섹터 배정";
        };
    }

    private YardAssignmentResultDTO buildResult(
            String plateNumber,
            VehicleDTO vehicle,
            WorkOrderDTO workOrder,
            ContainerDTO container,
            YardSectorDTO sector,
            String assignmentReason,
            String resultMessage
    ) {
        YardAssignmentResultDTO result =
                new YardAssignmentResultDTO();

        result.setSuccess(true);
        result.setMessage(resultMessage);

        result.setPlateNumber(plateNumber);

        result.setVehicleId(vehicle.getVehicleId());
        result.setVehicleType(vehicle.getVehicleType());
        result.setVehicleStructure(vehicle.getVehicleStructure());
        result.setAxleCount(vehicle.getAxleCount());

        result.setWorkOrderId(workOrder.getWorkOrderId());
        result.setContainerId(container.getContainerId());
        result.setContainerNumber(container.getContainerNumber());
        result.setContainerType(container.getContainerType());

        result.setSectorCategory(sector.getSectorCategory());
        result.setAssignedSectorId(sector.getSectorId());
        result.setAssignedSectorName(sector.getSectorName());

        result.setAssignmentReason(assignmentReason);
        result.setAssignmentMethod(METHOD_AUTO_RECOMMENDED);

        return result;
    }

    private String normalizePlateNumber(String plateNumber) {
        if (plateNumber == null || plateNumber.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "번호판 값이 비어 있습니다."
            );
        }

        return plateNumber
                .replaceAll("\\s+", "")
                .trim();
    }
}