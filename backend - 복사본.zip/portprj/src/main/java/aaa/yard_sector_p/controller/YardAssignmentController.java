package aaa.yard_sector_p.controller;

import aaa.yard_sector_p.model.YardAssignmentAdminRequestDTO.ApproveRequest;
import aaa.yard_sector_p.model.YardAssignmentAdminRequestDTO.InspectionHoldRequest;
import aaa.yard_sector_p.model.YardAssignmentAdminRequestDTO.ManualAssignRequest;
import aaa.yard_sector_p.model.YardAssignmentResultDTO;
import aaa.yard_sector_p.service.YardAssignmentService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/yard-assignment")
@CrossOrigin
public class YardAssignmentController {

    @Resource
    private YardAssignmentService yardAssignmentService;

    /**
     * OCR 인식 번호판을 기준으로 차량·작업지시·컨테이너 정보를 조회하고
     * 적합한 야드섹터를 자동 추천한다.
     *
     * POST /api/yard-assignment/recommend?plateNumber=01구8911
     */
    @PostMapping("/recommend")
    public YardAssignmentResultDTO recommend(
            @RequestParam String plateNumber
    ) {
        return yardAssignmentService.recommendByPlateNumber(plateNumber);
    }

    /**
     * AI가 추천한 현재 섹터를 관리자가 최종 승인한다.
     *
     * POST /api/yard-assignment/admin/approve
     * {
     *   "workOrderId": 21
     * }
     */
    @PostMapping("/admin/approve")
    public YardAssignmentResultDTO approveRecommendation(
            @RequestBody ApproveRequest request
    ) {
        return yardAssignmentService.approveRecommendation(request);
    }

    /**
     * 관리자가 다른 야드섹터를 직접 선택한다.
     *
     * POST /api/yard-assignment/admin/manual
     * {
     *   "workOrderId": 21,
     *   "sectorId": 42,
     *   "reason": "현장 혼잡으로 대체 섹터 지정"
     * }
     */
    @PostMapping("/admin/manual")
    public YardAssignmentResultDTO assignManually(
            @RequestBody ManualAssignRequest request
    ) {
        return yardAssignmentService.assignManually(request);
    }

    /**
     * 작업지시를 검사·보류 섹터로 이동시킨다.
     *
     * POST /api/yard-assignment/admin/inspection-hold
     * {
     *   "workOrderId": 21,
     *   "reason": "컨테이너 외관 파손 확인 필요"
     * }
     */
    @PostMapping("/admin/inspection-hold")
    public YardAssignmentResultDTO holdForInspection(
            @RequestBody InspectionHoldRequest request
    ) {
        return yardAssignmentService.holdForInspection(request);
    }
}