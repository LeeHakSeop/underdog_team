package aaa.trailer_p.service;

import aaa.trailer_p.model.TrailerDTO;
import aaa.trailer_p.model.TrailerMapper;
import jakarta.annotation.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Set;

@Service
public class TrailerService {

    private static final Set<String> ALLOWED_OPERATION_STATUSES = Set.of(
            "AVAILABLE",
            "ASSIGNED",
            "IN_OPERATION",
            "MAINTENANCE",
            "SUSPENDED"
    );

    @Resource
    private TrailerMapper mapper;

    @Transactional(readOnly = true)
    public List<TrailerDTO> list() {
        return mapper.list();
    }

    @Transactional(readOnly = true)
    public TrailerDTO detail(Long trailerId) {
        validatePositiveId(trailerId, "트레일러 ID");

        TrailerDTO trailer = mapper.detail(trailerId);

        if (trailer == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "트레일러 정보를 찾을 수 없습니다: " + trailerId
            );
        }

        return trailer;
    }

    @Transactional(readOnly = true)
    public TrailerDTO findByVehicleId(Long vehicleId) {
        validatePositiveId(vehicleId, "차량 ID");

        TrailerDTO trailer = mapper.findByVehicleId(vehicleId);

        if (trailer == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "차량에 연결된 트레일러 정보를 찾을 수 없습니다: "
                            + vehicleId
            );
        }

        return trailer;
    }

    @Transactional(readOnly = true)
    public TrailerDTO findByPlateNumber(String plateNumber) {
        String normalizedPlateNumber =
                normalizePlateNumber(plateNumber);

        TrailerDTO trailer =
                mapper.findByPlateNumber(normalizedPlateNumber);

        if (trailer == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "번호판에 해당하는 트레일러를 찾을 수 없습니다: "
                            + normalizedPlateNumber
            );
        }

        return trailer;
    }

    @Transactional(readOnly = true)
    public List<TrailerDTO> availableList() {
        return mapper.findAvailableTrailers();
    }

    @Transactional
    public TrailerDTO create(TrailerDTO dto) {
        validateCreateRequest(dto);

        if (mapper.countByVehicleId(dto.getVehicleId()) > 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "이미 트레일러 상세정보가 등록된 차량입니다."
            );
        }

        applyDefaults(dto);

        int inserted = mapper.insert(dto);

        if (inserted != 1 || dto.getTrailerId() == null) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "트레일러 정보를 등록하지 못했습니다."
            );
        }

        return detail(dto.getTrailerId());
    }

    @Transactional
    public TrailerDTO update(
            Long trailerId,
            TrailerDTO dto
    ) {
        validatePositiveId(trailerId, "트레일러 ID");

        TrailerDTO current = detail(trailerId);

        dto.setTrailerId(trailerId);
        dto.setVehicleId(current.getVehicleId());

        validateSpecification(dto);

        if (dto.getOperationStatus() == null
                || dto.getOperationStatus().isBlank()) {
            dto.setOperationStatus(
                    current.getOperationStatus()
            );
        } else {
            dto.setOperationStatus(
                    normalizeOperationStatus(
                            dto.getOperationStatus()
                    )
            );
        }

        applyBooleanDefaults(dto);

        int updated = mapper.update(dto);

        if (updated != 1) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "트레일러 정보를 수정하지 못했습니다."
            );
        }

        return detail(trailerId);
    }

    @Transactional
    public TrailerDTO syncByVehicleId(
            Long vehicleId,
            TrailerDTO dto
    ) {
        validatePositiveId(vehicleId, "차량 ID");

        if (dto == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "트레일러 정보가 없습니다."
            );
        }

        dto.setVehicleId(vehicleId);

        validateSpecification(dto);
        applyBooleanDefaults(dto);

        TrailerDTO current =
                mapper.findByVehicleId(vehicleId);

        if (current == null) {
            applyDefaults(dto);

            int inserted = mapper.insert(dto);

            if (inserted != 1
                    || dto.getTrailerId() == null) {
                throw new ResponseStatusException(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "차량 기준 트레일러 정보를 생성하지 못했습니다."
                );
            }

            return detail(dto.getTrailerId());
        }

        dto.setTrailerId(current.getTrailerId());

        if (dto.getOperationStatus() == null
                || dto.getOperationStatus().isBlank()) {
            dto.setOperationStatus(
                    current.getOperationStatus()
            );
        }

        int updated = mapper.updateByVehicleId(dto);

        if (updated != 1) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "차량 기준 트레일러 정보를 동기화하지 못했습니다."
            );
        }

        return findByVehicleId(vehicleId);
    }

    @Transactional
    public TrailerDTO changeOperationStatus(
            Long trailerId,
            String operationStatus
    ) {
        validatePositiveId(trailerId, "트레일러 ID");

        String normalizedStatus =
                normalizeOperationStatus(operationStatus);

        detail(trailerId);

        int updated = mapper.updateOperationStatus(
                trailerId,
                normalizedStatus
        );

        if (updated != 1) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "트레일러 운행 상태를 변경하지 못했습니다."
            );
        }

        return detail(trailerId);
    }

    @Transactional
    public TrailerDTO changeOperationStatusByVehicleId(
            Long vehicleId,
            String operationStatus
    ) {
        validatePositiveId(vehicleId, "차량 ID");

        String normalizedStatus =
                normalizeOperationStatus(operationStatus);

        findByVehicleId(vehicleId);

        int updated =
                mapper.updateOperationStatusByVehicleId(
                        vehicleId,
                        normalizedStatus
                );

        if (updated != 1) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "차량 기준 트레일러 운행 상태를 변경하지 못했습니다."
            );
        }

        return findByVehicleId(vehicleId);
    }

    @Transactional
    public void delete(Long trailerId) {
        validatePositiveId(trailerId, "트레일러 ID");

        detail(trailerId);

        int deleted = mapper.delete(trailerId);

        if (deleted != 1) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "트레일러 정보를 삭제하지 못했습니다."
            );
        }
    }

    private void validateCreateRequest(TrailerDTO dto) {
        if (dto == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "트레일러 등록 정보가 없습니다."
            );
        }

        validatePositiveId(
                dto.getVehicleId(),
                "차량 ID"
        );

        validateSpecification(dto);
        validateOperationStatus(dto.getOperationStatus());
    }

    private void validateSpecification(TrailerDTO dto) {
        if (dto == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "트레일러 정보가 없습니다."
            );
        }

        if (dto.getTrafficSurveyClass() != null
                && (
                dto.getTrafficSurveyClass() < 1
                        || dto.getTrafficSurveyClass() > 12
        )) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "교통조사 차종은 1종부터 12종 사이여야 합니다."
            );
        }

        if (dto.getAxleCount() != null
                && (
                dto.getAxleCount() < 1
                        || dto.getAxleCount() > 12
        )) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "축수는 1부터 12 사이여야 합니다."
            );
        }

        if (dto.getMaxLoadTon() != null
                && dto.getMaxLoadTon().signum() < 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "최대 적재량은 0 이상이어야 합니다."
            );
        }

        if (dto.getGrossWeightTon() != null
                && dto.getGrossWeightTon().signum() < 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "총중량은 0 이상이어야 합니다."
            );
        }
    }

    private void validateOperationStatus(
            String operationStatus
    ) {
        if (operationStatus == null
                || operationStatus.isBlank()) {
            return;
        }

        normalizeOperationStatus(operationStatus);
    }

    private String normalizeOperationStatus(
            String operationStatus
    ) {
        if (operationStatus == null
                || operationStatus.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "트레일러 운행 상태가 비어 있습니다."
            );
        }

        String normalizedStatus =
                operationStatus
                        .trim()
                        .toUpperCase();

        if (!ALLOWED_OPERATION_STATUSES.contains(
                normalizedStatus
        )) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "지원하지 않는 트레일러 운행 상태입니다: "
                            + operationStatus
            );
        }

        return normalizedStatus;
    }

    private void applyDefaults(TrailerDTO dto) {
        applyBooleanDefaults(dto);

        if (dto.getTrailerStructure() == null
                || dto.getTrailerStructure().isBlank()) {
            dto.setTrailerStructure("TRAILER");
        }

        if (dto.getOperationStatus() == null
                || dto.getOperationStatus().isBlank()) {
            dto.setOperationStatus("AVAILABLE");
        } else {
            dto.setOperationStatus(
                    normalizeOperationStatus(
                            dto.getOperationStatus()
                    )
            );
        }
    }

    private void applyBooleanDefaults(TrailerDTO dto) {
        if (dto.getRequiresWeighing() == null) {
            dto.setRequiresWeighing(false);
        }

        if (dto.getDangerousGoodsVehicle() == null) {
            dto.setDangerousGoodsVehicle(false);
        }

        if (dto.getReeferVehicle() == null) {
            dto.setReeferVehicle(false);
        }

        if (dto.getSpecialTransport() == null) {
            dto.setSpecialTransport(false);
        }
    }

    private void validatePositiveId(
            Long id,
            String fieldName
    ) {
        if (id == null || id <= 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    fieldName + "가 올바르지 않습니다."
            );
        }
    }

    private String normalizePlateNumber(
            String plateNumber
    ) {
        if (plateNumber == null
                || plateNumber.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "번호판 값이 비어 있습니다."
            );
        }

        return plateNumber
                .replaceAll("\\s+", "")
                .trim();
    }
}