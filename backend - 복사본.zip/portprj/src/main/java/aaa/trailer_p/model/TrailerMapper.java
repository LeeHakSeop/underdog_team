package aaa.trailer_p.model;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface TrailerMapper {

    @Select("""
            SELECT
                t.trailer_id AS trailerId,
                t.vehicle_id AS vehicleId,
                t.trailer_no AS trailerNo,
                t.trailer_structure AS trailerStructure,
                t.traffic_survey_class AS trafficSurveyClass,
                t.axle_count AS axleCount,
                t.max_load_ton AS maxLoadTon,
                t.gross_weight_ton AS grossWeightTon,
                t.requires_weighing AS requiresWeighing,
                t.dangerous_goods_vehicle AS dangerousGoodsVehicle,
                t.reefer_vehicle AS reeferVehicle,
                t.special_transport AS specialTransport,
                t.connection_type AS connectionType,
                t.operation_status AS operationStatus,
                t.created_at AS createdAt,
                t.updated_at AS updatedAt
            FROM trailer t
            ORDER BY t.trailer_id DESC
            """)
    List<TrailerDTO> list();

    @Select("""
            SELECT
                t.trailer_id AS trailerId,
                t.vehicle_id AS vehicleId,
                t.trailer_no AS trailerNo,
                t.trailer_structure AS trailerStructure,
                t.traffic_survey_class AS trafficSurveyClass,
                t.axle_count AS axleCount,
                t.max_load_ton AS maxLoadTon,
                t.gross_weight_ton AS grossWeightTon,
                t.requires_weighing AS requiresWeighing,
                t.dangerous_goods_vehicle AS dangerousGoodsVehicle,
                t.reefer_vehicle AS reeferVehicle,
                t.special_transport AS specialTransport,
                t.connection_type AS connectionType,
                t.operation_status AS operationStatus,
                t.created_at AS createdAt,
                t.updated_at AS updatedAt
            FROM trailer t
            WHERE t.trailer_id = #{trailerId}
            """)
    TrailerDTO detail(@Param("trailerId") Long trailerId);

    @Select("""
            SELECT
                t.trailer_id AS trailerId,
                t.vehicle_id AS vehicleId,
                t.trailer_no AS trailerNo,
                t.trailer_structure AS trailerStructure,
                t.traffic_survey_class AS trafficSurveyClass,
                t.axle_count AS axleCount,
                t.max_load_ton AS maxLoadTon,
                t.gross_weight_ton AS grossWeightTon,
                t.requires_weighing AS requiresWeighing,
                t.dangerous_goods_vehicle AS dangerousGoodsVehicle,
                t.reefer_vehicle AS reeferVehicle,
                t.special_transport AS specialTransport,
                t.connection_type AS connectionType,
                t.operation_status AS operationStatus,
                t.created_at AS createdAt,
                t.updated_at AS updatedAt
            FROM trailer t
            WHERE t.vehicle_id = #{vehicleId}
            """)
    TrailerDTO findByVehicleId(@Param("vehicleId") Long vehicleId);

    @Select("""
            SELECT
                t.trailer_id AS trailerId,
                t.vehicle_id AS vehicleId,
                t.trailer_no AS trailerNo,
                t.trailer_structure AS trailerStructure,
                t.traffic_survey_class AS trafficSurveyClass,
                t.axle_count AS axleCount,
                t.max_load_ton AS maxLoadTon,
                t.gross_weight_ton AS grossWeightTon,
                t.requires_weighing AS requiresWeighing,
                t.dangerous_goods_vehicle AS dangerousGoodsVehicle,
                t.reefer_vehicle AS reeferVehicle,
                t.special_transport AS specialTransport,
                t.connection_type AS connectionType,
                t.operation_status AS operationStatus,
                t.created_at AS createdAt,
                t.updated_at AS updatedAt
            FROM trailer t
            JOIN vehicle v
              ON v.vehicle_id = t.vehicle_id
            WHERE REPLACE(v.plate_number, ' ', '') =
                  REPLACE(#{plateNumber}, ' ', '')
            LIMIT 1
            """)
    TrailerDTO findByPlateNumber(@Param("plateNumber") String plateNumber);

    @Select("""
            SELECT
                t.trailer_id AS trailerId,
                t.vehicle_id AS vehicleId,
                t.trailer_no AS trailerNo,
                t.trailer_structure AS trailerStructure,
                t.traffic_survey_class AS trafficSurveyClass,
                t.axle_count AS axleCount,
                t.max_load_ton AS maxLoadTon,
                t.gross_weight_ton AS grossWeightTon,
                t.requires_weighing AS requiresWeighing,
                t.dangerous_goods_vehicle AS dangerousGoodsVehicle,
                t.reefer_vehicle AS reeferVehicle,
                t.special_transport AS specialTransport,
                t.connection_type AS connectionType,
                t.operation_status AS operationStatus,
                t.created_at AS createdAt,
                t.updated_at AS updatedAt
            FROM trailer t
            JOIN vehicle v
              ON v.vehicle_id = t.vehicle_id
            WHERE t.operation_status = 'AVAILABLE'
              AND COALESCE(v.is_registered, FALSE) = TRUE
              AND NOT EXISTS (
                  SELECT 1
                  FROM work_order wo
                  WHERE wo.trailer_vehicle_id = t.vehicle_id
                    AND wo.work_status IN (
                        'DISPATCH_WAITING',
                        'APPROVED',
                        'GATE_IN',
                        'IN_PROGRESS'
                    )
              )
            ORDER BY t.trailer_id ASC
            """)
    List<TrailerDTO> findAvailableTrailers();

    @Select("""
            SELECT COUNT(*)
            FROM trailer
            WHERE vehicle_id = #{vehicleId}
            """)
    int countByVehicleId(@Param("vehicleId") Long vehicleId);

    @Insert("""
            INSERT INTO trailer (
                vehicle_id,
                trailer_no,
                trailer_structure,
                traffic_survey_class,
                axle_count,
                max_load_ton,
                gross_weight_ton,
                requires_weighing,
                dangerous_goods_vehicle,
                reefer_vehicle,
                special_transport,
                connection_type,
                operation_status,
                created_at,
                updated_at
            )
            VALUES (
                #{vehicleId},
                #{trailerNo},
                #{trailerStructure},
                #{trafficSurveyClass},
                #{axleCount},
                #{maxLoadTon},
                #{grossWeightTon},
                COALESCE(#{requiresWeighing}, FALSE),
                COALESCE(#{dangerousGoodsVehicle}, FALSE),
                COALESCE(#{reeferVehicle}, FALSE),
                COALESCE(#{specialTransport}, FALSE),
                #{connectionType},
                COALESCE(#{operationStatus}, 'AVAILABLE'),
                CURRENT_TIMESTAMP,
                CURRENT_TIMESTAMP
            )
            """)
    @Options(
            useGeneratedKeys = true,
            keyProperty = "trailerId",
            keyColumn = "trailer_id"
    )
    int insert(TrailerDTO dto);

    @Update("""
            UPDATE trailer
            SET
                trailer_no = #{trailerNo},
                trailer_structure = #{trailerStructure},
                traffic_survey_class = #{trafficSurveyClass},
                axle_count = #{axleCount},
                max_load_ton = #{maxLoadTon},
                gross_weight_ton = #{grossWeightTon},
                requires_weighing =
                    COALESCE(#{requiresWeighing}, FALSE),
                dangerous_goods_vehicle =
                    COALESCE(#{dangerousGoodsVehicle}, FALSE),
                reefer_vehicle =
                    COALESCE(#{reeferVehicle}, FALSE),
                special_transport =
                    COALESCE(#{specialTransport}, FALSE),
                connection_type = #{connectionType},
                operation_status =
                    COALESCE(#{operationStatus}, operation_status),
                updated_at = CURRENT_TIMESTAMP
            WHERE trailer_id = #{trailerId}
            """)
    int update(TrailerDTO dto);

    @Update("""
            UPDATE trailer
            SET
                trailer_no = #{trailerNo},
                trailer_structure = #{trailerStructure},
                traffic_survey_class = #{trafficSurveyClass},
                axle_count = #{axleCount},
                max_load_ton = #{maxLoadTon},
                gross_weight_ton = #{grossWeightTon},
                requires_weighing =
                    COALESCE(#{requiresWeighing}, FALSE),
                dangerous_goods_vehicle =
                    COALESCE(#{dangerousGoodsVehicle}, FALSE),
                reefer_vehicle =
                    COALESCE(#{reeferVehicle}, FALSE),
                special_transport =
                    COALESCE(#{specialTransport}, FALSE),
                connection_type = #{connectionType},
                updated_at = CURRENT_TIMESTAMP
            WHERE vehicle_id = #{vehicleId}
            """)
    int updateByVehicleId(TrailerDTO dto);

    @Update("""
            UPDATE trailer
            SET
                operation_status = #{operationStatus},
                updated_at = CURRENT_TIMESTAMP
            WHERE trailer_id = #{trailerId}
            """)
    int updateOperationStatus(
            @Param("trailerId") Long trailerId,
            @Param("operationStatus") String operationStatus
    );

    @Update("""
            UPDATE trailer
            SET
                operation_status = #{operationStatus},
                updated_at = CURRENT_TIMESTAMP
            WHERE vehicle_id = #{vehicleId}
            """)
    int updateOperationStatusByVehicleId(
            @Param("vehicleId") Long vehicleId,
            @Param("operationStatus") String operationStatus
    );

    @Delete("""
            DELETE FROM trailer
            WHERE trailer_id = #{trailerId}
            """)
    int delete(@Param("trailerId") Long trailerId);
    @Delete("""
        DELETE FROM trailer
        WHERE vehicle_id = #{vehicleId}
        """)
    int deleteByVehicleId(@Param("vehicleId") Long vehicleId);
}