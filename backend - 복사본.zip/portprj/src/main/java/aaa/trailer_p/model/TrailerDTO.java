package aaa.trailer_p.model;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class TrailerDTO {

    private Long trailerId;
    private Long vehicleId;

    private String trailerNo;
    private String trailerStructure;

    private Integer trafficSurveyClass;
    private Integer axleCount;

    private BigDecimal maxLoadTon;
    private BigDecimal grossWeightTon;

    private Boolean requiresWeighing;
    private Boolean dangerousGoodsVehicle;
    private Boolean reeferVehicle;
    private Boolean specialTransport;

    private String connectionType;
    private String operationStatus;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}