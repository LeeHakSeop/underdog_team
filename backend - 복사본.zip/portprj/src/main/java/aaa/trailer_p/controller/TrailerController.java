package aaa.trailer_p.controller;

import aaa.trailer_p.model.TrailerDTO;
import aaa.trailer_p.service.TrailerService;
import jakarta.annotation.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/trailers")
public class TrailerController {

    @Resource
    private TrailerService service;

    @GetMapping
    public List<TrailerDTO> list() {
        return service.list();
    }

    @GetMapping("/available")
    public List<TrailerDTO> availableList() {
        return service.availableList();
    }

    @GetMapping("/{trailerId}")
    public TrailerDTO detail(
            @PathVariable Long trailerId
    ) {
        return service.detail(trailerId);
    }

    @GetMapping("/by-vehicle/{vehicleId}")
    public TrailerDTO findByVehicleId(
            @PathVariable Long vehicleId
    ) {
        return service.findByVehicleId(vehicleId);
    }

    @GetMapping("/by-plate")
    public TrailerDTO findByPlateNumber(
            @RequestParam String plateNumber
    ) {
        return service.findByPlateNumber(plateNumber);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TrailerDTO create(
            @RequestBody TrailerDTO dto
    ) {
        return service.create(dto);
    }

    @PutMapping("/{trailerId}")
    public TrailerDTO update(
            @PathVariable Long trailerId,
            @RequestBody TrailerDTO dto
    ) {
        return service.update(trailerId, dto);
    }

    @PutMapping("/by-vehicle/{vehicleId}")
    public TrailerDTO syncByVehicleId(
            @PathVariable Long vehicleId,
            @RequestBody TrailerDTO dto
    ) {
        return service.syncByVehicleId(vehicleId, dto);
    }

    @PatchMapping("/{trailerId}/status")
    public TrailerDTO changeOperationStatus(
            @PathVariable Long trailerId,
            @RequestBody Map<String, String> request
    ) {
        return service.changeOperationStatus(
                trailerId,
                request.get("operationStatus")
        );
    }

    @PatchMapping("/by-vehicle/{vehicleId}/status")
    public TrailerDTO changeOperationStatusByVehicleId(
            @PathVariable Long vehicleId,
            @RequestBody Map<String, String> request
    ) {
        return service.changeOperationStatusByVehicleId(
                vehicleId,
                request.get("operationStatus")
        );
    }

    @DeleteMapping("/{trailerId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(
            @PathVariable Long trailerId
    ) {
        service.delete(trailerId);
    }
}