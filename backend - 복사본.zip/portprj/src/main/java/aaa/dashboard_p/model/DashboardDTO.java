package aaa.dashboard_p.model;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class DashboardDTO {

    private DashboardSummaryDTO summary;

    private List<DashboardWorkStatusDTO> workStatusList;

    // WBS 13 - AI 야드배정 방식별 통계
    private List<Map<String, Object>> assignmentMethodList;

    // WBS 13 - 특수화물 유형별 통계
    private List<Map<String, Object>> specialCargoList;

    private List<DashboardRecentWorkDTO> recentWorkOrders;

    private List<DashboardSectorDTO> sectorList;
}