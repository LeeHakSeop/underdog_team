package aaa.dashboard_p.model;

import lombok.Data;

@Data
public class DashboardSectorDTO {

    private Long sectorId;
    private String sectorName;
    private String blockName;
    private String sectorStatus;

    // WBS13 추가
    private String sectorCategory;

    private Integer waitingVehicleCount;

    private String guideMessage;
    private String altWaitingArea;

    // 섹터 기능
    private Boolean reeferPowerAvailable;
    private Boolean dangerousGoodsAllowed;
    private Boolean oogAllowed;
    private Boolean heavyCargoAllowed;

    // Dashboard 혼잡도
    private String congestionLevel;
    private Integer congestionRate;
}