package aaa.dashboard_p.model;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class DashboardRecentWorkDTO {

    // 작업
    private Long workOrderId;
    private String workType;
    private String workStatus;
    private LocalDateTime reservedTime;

    // AI 배정
    private String assignmentMethod;
    private String assignmentReason;
    private Long assignedSectorId;

    // 차량
    private String plateNumber;
    private String vehicleStructure;
    private Integer trafficSurveyClass;
    private Integer axleCount;
    private BigDecimal grossWeightTon;
    private Boolean requiresWeighing;

    // 기사/운송사
    private String driverName;
    private String carrierName;

    // 컨테이너
    private String containerNumber;
    private String containerType;
    private String cargoFlowType;
    private String loadStatus;

    private Boolean reefer;
    private Boolean dangerousGoods;
    private Boolean oog;
    private Boolean heavyCargo;
    private Boolean inspectionRequired;

    // 야드
    private String sectorName;
    private String sectorCategory;
}