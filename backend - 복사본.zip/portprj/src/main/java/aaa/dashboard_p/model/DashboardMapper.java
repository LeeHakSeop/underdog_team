package aaa.dashboard_p.model;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface DashboardMapper {

    /**
     * 관리자 대시보드 상단 통합 요약.
     *
     * 기존 운영 통계에 다음 WBS 13 항목을 추가한다.
     * - AI 자동추천 / 관리자 승인 / 수동배정 건수
     * - 특수화물 건수
     * - 전체 야드 대기 차량
     *
     * recognitionRetry는 현재 DB에 재촬영 여부를 구분하는 컬럼이 없어
     * 안전하게 0으로 반환한다. 재촬영 통계를 실제 집계하려면
     * plate_recognition에 retry 여부 또는 attempt_no 컬럼이 필요하다.
     */
    @Select("""
            SELECT
                (SELECT COUNT(*) FROM vehicle) AS totalVehicles,

                (SELECT COUNT(*)
                   FROM users
                  WHERE status = 'PENDING') AS pendingUsers,

                (SELECT COUNT(*)
                   FROM users
                  WHERE role_code = 'CARRIER'
                    AND status = 'PENDING') AS pendingCarriers,

                (SELECT COUNT(*)
                   FROM users
                  WHERE role_code = 'DRIVER'
                    AND status = 'PENDING') AS pendingDrivers,

                (SELECT COUNT(*)
                   FROM gate_log
                  WHERE in_out_type = 'IN'
                    AND process_result = 'GATE_SUCCESS'
                    AND DATE(entry_time) = CURRENT_DATE) AS todayGateIn,

                (SELECT COUNT(*)
                   FROM gate_log
                  WHERE in_out_type = 'OUT'
                    AND process_result = 'GATE_SUCCESS'
                    AND DATE(exit_time) = CURRENT_DATE) AS todayGateOut,

                (SELECT COUNT(*)
                   FROM plate_recognition) AS recognitionTotal,

                (SELECT COUNT(*)
                   FROM plate_recognition
                  WHERE is_success = true) AS recognitionSuccess,

                (SELECT COUNT(*)
                   FROM plate_recognition
                  WHERE is_success = false) AS recognitionFail,

                0 AS recognitionRetry,

                (SELECT COUNT(*)
                   FROM exception_log
                  WHERE process_status IS NULL
                     OR process_status <> 'PROCESSED') AS exceptionOpen,

                (SELECT COUNT(*)
                   FROM work_order) AS workTotal,

                (SELECT COUNT(*)
                   FROM work_order
                  WHERE work_status IN ('DISPATCH_WAITING', 'APPROVED')) AS workReady,

                (SELECT COUNT(*)
                   FROM work_order
                  WHERE work_status IN ('GATE_IN', 'IN_PROGRESS')) AS workInProgress,

                (SELECT COUNT(*)
                   FROM work_order
                  WHERE work_status IN ('COMPLETED', 'GATE_OUT')) AS workDone,

                (SELECT COUNT(*)
                   FROM work_order
                  WHERE assignment_method = 'AUTO_RECOMMENDED') AS assignmentAutoRecommended,

                (SELECT COUNT(*)
                   FROM work_order
                  WHERE assignment_method = 'ADMIN_APPROVED') AS assignmentAdminApproved,

                (SELECT COUNT(*)
                   FROM work_order
                  WHERE assignment_method = 'MANUAL') AS assignmentManual,

                (SELECT COUNT(*)
                   FROM container
                  WHERE reefer = true) AS reeferCount,

                (SELECT COUNT(*)
                   FROM container
                  WHERE dangerous_goods = true) AS dangerousGoodsCount,

                (SELECT COUNT(*)
                   FROM container
                  WHERE oog = true) AS oogCount,

                (SELECT COUNT(*)
                   FROM container
                  WHERE heavy_cargo = true) AS heavyCargoCount,

                (SELECT COUNT(*)
                   FROM container
                  WHERE inspection_required = true) AS inspectionRequiredCount,

                (SELECT COALESCE(SUM(waiting_vehicle_count), 0)
                   FROM yard_sector) AS totalWaitingVehicles
            """)
    DashboardSummaryDTO summary();

    @Select("""
            SELECT
                COALESCE(work_status, '미지정') AS workStatus,
                COUNT(*) AS workCount
            FROM work_order
            GROUP BY work_status
            ORDER BY workCount DESC, workStatus ASC
            """)
    List<DashboardWorkStatusDTO> workStatusList();

    /**
     * AI 배정 방식별 집계.
     *
     * 반환 Map 키:
     * - assignmentMethod
     * - assignmentCount
     */
    @Select("""
            SELECT
                COALESCE(assignment_method, 'UNASSIGNED') AS assignmentMethod,
                COUNT(*) AS assignmentCount
            FROM work_order
            GROUP BY assignment_method
            ORDER BY assignmentCount DESC, assignmentMethod ASC
            """)
    List<Map<String, Object>> assignmentMethodList();

    /**
     * 특수화물별 집계.
     *
     * 반환 Map 키:
     * - cargoType
     * - cargoCount
     */
    @Select("""
            SELECT 'REEFER' AS cargoType, COUNT(*) AS cargoCount
              FROM container
             WHERE reefer = true

            UNION ALL

            SELECT 'DANGEROUS_GOODS' AS cargoType, COUNT(*) AS cargoCount
              FROM container
             WHERE dangerous_goods = true

            UNION ALL

            SELECT 'OOG' AS cargoType, COUNT(*) AS cargoCount
              FROM container
             WHERE oog = true

            UNION ALL

            SELECT 'HEAVY_CARGO' AS cargoType, COUNT(*) AS cargoCount
              FROM container
             WHERE heavy_cargo = true

            UNION ALL

            SELECT 'INSPECTION_REQUIRED' AS cargoType, COUNT(*) AS cargoCount
              FROM container
             WHERE inspection_required = true
            """)
    List<Map<String, Object>> specialCargoList();

    /**
     * 최근 작업 조회.
     *
     * work_order.assigned_sector_id를 우선 사용하고,
     * 값이 없을 때만 container.sector_id를 사용한다.
     */
    @Select("""
            SELECT
                wo.work_order_id AS workOrderId,
                wo.work_type AS workType,
                wo.work_status AS workStatus,
                wo.reserved_time AS reservedTime,
                wo.assignment_method AS assignmentMethod,
                wo.assignment_reason AS assignmentReason,
                wo.assigned_sector_id AS assignedSectorId,

                v.plate_number AS plateNumber,
                v.vehicle_structure AS vehicleStructure,
                v.traffic_survey_class AS trafficSurveyClass,
                v.axle_count AS axleCount,
                v.gross_weight_ton AS grossWeightTon,
                v.requires_weighing AS requiresWeighing,

                d.driver_name AS driverName,
                ca.carrier_name AS carrierName,

                c.container_number AS containerNumber,
                c.container_type AS containerType,
                c.cargo_flow_type AS cargoFlowType,
                c.load_status AS loadStatus,
                c.reefer AS reefer,
                c.dangerous_goods AS dangerousGoods,
                c.oog AS oog,
                c.heavy_cargo AS heavyCargo,
                c.inspection_required AS inspectionRequired,

                ys.sector_name AS sectorName,
                ys.sector_category AS sectorCategory
            FROM work_order wo
            LEFT JOIN vehicle v
                   ON wo.vehicle_id = v.vehicle_id
            LEFT JOIN driver d
                   ON wo.driver_id = d.driver_id
            LEFT JOIN carrier ca
                   ON d.carrier_id = ca.carrier_id
            LEFT JOIN container c
                   ON wo.container_id = c.container_id
            LEFT JOIN yard_sector ys
                   ON ys.sector_id = COALESCE(
                       wo.assigned_sector_id,
                       c.sector_id
                   )
            ORDER BY
                wo.reserved_time DESC NULLS LAST,
                wo.work_order_id DESC
            LIMIT 8
            """)
    List<DashboardRecentWorkDTO> recentWorkOrders();

    /**
     * 야드 섹터 운영 현황.
     *
     * 실제 점유율을 계산할 수 있는 capacity 컬럼은 현재 확인되지 않았으므로,
     * waiting_vehicle_count를 기준으로 혼잡 단계를 계산한다.
     */
    @Select("""
            SELECT
                sector_id AS sectorId,
                sector_name AS sectorName,
                block_name AS blockName,
                sector_status AS sectorStatus,
                sector_category AS sectorCategory,
                COALESCE(waiting_vehicle_count, 0) AS waitingVehicleCount,
                guide_message AS guideMessage,
                alt_waiting_area AS altWaitingArea,

                reefer_power_available AS reeferPowerAvailable,
                dangerous_goods_allowed AS dangerousGoodsAllowed,
                oog_allowed AS oogAllowed,
                heavy_cargo_allowed AS heavyCargoAllowed,

                CASE
                    WHEN COALESCE(waiting_vehicle_count, 0) >= 8 THEN 'HIGH'
                    WHEN COALESCE(waiting_vehicle_count, 0) >= 4 THEN 'MEDIUM'
                    ELSE 'LOW'
                END AS congestionLevel,

                LEAST(
                    100,
                    COALESCE(waiting_vehicle_count, 0) * 10
                ) AS congestionRate
            FROM yard_sector
            ORDER BY
                waiting_vehicle_count DESC NULLS LAST,
                sector_id ASC
            LIMIT 12
            """)
    List<DashboardSectorDTO> sectorList();
}