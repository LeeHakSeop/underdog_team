package aaa.dashboard_p.model;

import lombok.Data;

@Data
public class DashboardSummaryDTO {

    // 기존 운영 통계
    private Integer totalVehicles;
    private Integer pendingUsers;
    private Integer pendingCarriers;
    private Integer pendingDrivers;

    private Integer todayGateIn;
    private Integer todayGateOut;

    private Integer recognitionTotal;
    private Integer recognitionSuccess;
    private Integer recognitionFail;
    private Integer recognitionRetry;

    private Integer exceptionOpen;

    private Integer workTotal;
    private Integer workReady;
    private Integer workInProgress;
    private Integer workDone;

    // WBS 13 - AI 야드배정 통계
    private Integer assignmentAutoRecommended;
    private Integer assignmentAdminApproved;
    private Integer assignmentManual;

    // WBS 13 - 특수화물 통계
    private Integer reeferCount;
    private Integer dangerousGoodsCount;
    private Integer oogCount;
    private Integer heavyCargoCount;
    private Integer inspectionRequiredCount;

    // WBS 13 - 야드 운영 통계
    private Integer totalWaitingVehicles;
}