package aaa.dashboard_p.controller;

import aaa.dashboard_p.model.DashboardDTO;
import aaa.dashboard_p.service.DashboardService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @Resource
    private DashboardService service;

    /**
     * WBS 13 관리자 통합 대시보드 조회
     *
     * 포함 데이터
     * - 운영 요약 통계
     * - 작업 상태 통계
     * - AI 자동배정 통계
     * - 특수화물 통계
     * - 최근 작업
     * - 야드 섹터 및 혼잡도
     */
    @GetMapping("/admin")
    public DashboardDTO admin() {
        return service.admin();
    }
}