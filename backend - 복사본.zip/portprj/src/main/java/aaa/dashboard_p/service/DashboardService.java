package aaa.dashboard_p.service;

import aaa.dashboard_p.model.DashboardDTO;
import aaa.dashboard_p.model.DashboardMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DashboardService {

    @Resource
    private DashboardMapper mapper;

    /**
     * 관리자 대시보드 통합 조회.
     *
     * WBS 13 반영 항목:
     * - 기본 운영 통계
     * - 작업 상태별 통계
     * - AI 야드배정 방식별 통계
     * - 특수화물 유형별 통계
     * - 최근 작업
     * - 야드 섹터 및 혼잡도
     */
    @Transactional(readOnly = true)
    public DashboardDTO admin() {
        DashboardDTO dto = new DashboardDTO();

        dto.setSummary(mapper.summary());
        dto.setWorkStatusList(mapper.workStatusList());
        dto.setAssignmentMethodList(mapper.assignmentMethodList());
        dto.setSpecialCargoList(mapper.specialCargoList());
        dto.setRecentWorkOrders(mapper.recentWorkOrders());
        dto.setSectorList(mapper.sectorList());

        return dto;
    }
}