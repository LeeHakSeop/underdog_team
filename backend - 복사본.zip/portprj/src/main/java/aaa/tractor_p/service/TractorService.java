package aaa.tractor_p.service;

import aaa.tractor_p.model.TractorDTO;
import aaa.tractor_p.model.TractorMapper;
import jakarta.annotation.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Set;

@Service
public class TractorService {

    private static final Set<String> ALLOWED_OPERATION_STATUSES = Set.of(
            "AVAILABLE",
            "ASSIGNED",
            "IN_OPERATION",
            "MAINTENANCE",
            "SUSPENDED"
    );

    @Resource
    private TractorMapper mapper;

    @Transactional(readOnly = true)
    public List<TractorDTO> list() {
        return mapper.list();
    }

    @Transactional(readOnly = true)
    public TractorDTO detail(Long tractorId) {
        validatePositiveId(tractorId, "트랙터 ID");

        TractorDTO tractor = mapper.detail(tractorId);

        if (tractor == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "트랙터 정보를 찾을 수 없습니다: " + tractorId
            );
        }

        return tractor;
    }

    @Transactional(readOnly = true)
    public TractorDTO findByVehicleId(Long vehicleId) {
        validatePositiveId(vehicleId, "차량 ID");

        TractorDTO tractor = mapper.findByVehicleId(vehicleId);

        if (tractor == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "차량에 연결된 트랙터 정보를 찾을 수 없습니다: " + vehicleId
            );
        }

        return tractor;
    }

    @Transactional(readOnly = true)
    public TractorDTO findByPlateNumber(String plateNumber) {
        String normalizedPlateNumber = normalizePlateNumber(plateNumber);

        TractorDTO tractor = mapper.findByPlateNumber(normalizedPlateNumber);

        if (tractor == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "번호판에 해당하는 트랙터를 찾을 수 없습니다: " + normalizedPlateNumber
            );
        }

        return tractor;
    }

    @Transactional(readOnly = true)
    public List<TractorDTO> availableList() {
        return mapper.findAvailableTractors();
    }

    @Transactional
    public TractorDTO create(TractorDTO dto) {
        validateCreateRequest(dto);

        if (mapper.countByVehicleId(dto.getVehicleId()) > 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "이미 트랙터 상세정보가 등록된 차량입니다."
            );
        }

        applyDefaults(dto);

        int inserted = mapper.insert(dto);

        if (inserted == 0 || dto.getTractorId() == null) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "트랙터 정보를 등록하지 못했습니다."
            );
        }

        return detail(dto.getTractorId());
    }

    @Transactional
    public TractorDTO update(Long tractorId, TractorDTO dto) {
        validatePositiveId(tractorId, "트랙터 ID");

        TractorDTO current = detail(tractorId);

        dto.setTractorId(tractorId);
        dto.setVehicleId(current.getVehicleId());

        validateSpecification(dto);
        validateOperationStatus(dto.getOperationStatus());

        int updated = mapper.update(dto);

        if (updated == 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "트랙터 정보를 수정하지 못했습니다."
            );
        }

        return detail(tractorId);
    }

    @Transactional
    public TractorDTO syncByVehicleId(Long vehicleId, TractorDTO dto) {
        validatePositiveId(vehicleId, "차량 ID");

        TractorDTO current = mapper.findByVehicleId(vehicleId);

        dto.setVehicleId(vehicleId);
        validateSpecification(dto);

        if (current == null) {
            applyDefaults(dto);

            int inserted = mapper.insert(dto);

            if (inserted == 0 || dto.getTractorId() == null) {
                throw new ResponseStatusException(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "차량 기준 트랙터 정보를 생성하지 못했습니다."
                );
            }

            return detail(dto.getTractorId());
        }

        dto.setTractorId(current.getTractorId());

        if (dto.getOperationStatus() == null || dto.getOperationStatus().isBlank()) {
            dto.setOperationStatus(current.getOperationStatus());
        }

        int updated = mapper.updateByVehicleId(dto);

        if (updated == 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "차량 기준 트랙터 정보를 동기화하지 못했습니다."
            );
        }

        return findByVehicleId(vehicleId);
    }

    @Transactional
    public TractorDTO changeOperationStatus(
            Long tractorId,
            String operationStatus
    ) {
        validatePositiveId(tractorId, "트랙터 ID");

        String normalizedStatus = normalizeOperationStatus(operationStatus);
        detail(tractorId);

        int updated = mapper.updateOperationStatus(
                tractorId,
                normalizedStatus
        );

        if (updated == 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "트랙터 운행 상태를 변경하지 못했습니다."
            );
        }

        return detail(tractorId);
    }

    @Transactional
    public TractorDTO changeOperationStatusByVehicleId(
            Long vehicleId,
            String operationStatus
    ) {
        validatePositiveId(vehicleId, "차량 ID");

        String normalizedStatus = normalizeOperationStatus(operationStatus);
        findByVehicleId(vehicleId);

        int updated = mapper.updateOperationStatusByVehicleId(
                vehicleId,
                normalizedStatus
        );

        if (updated == 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "차량 기준 트랙터 운행 상태를 변경하지 못했습니다."
            );
        }

        return findByVehicleId(vehicleId);
    }

    @Transactional
    public void delete(Long tractorId) {
        validatePositiveId(tractorId, "트랙터 ID");
        detail(tractorId);

        int deleted = mapper.delete(tractorId);

        if (deleted == 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "트랙터 정보를 삭제하지 못했습니다."
            );
        }
    }

    private void validateCreateRequest(TractorDTO dto) {
        if (dto == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "트랙터 등록 정보가 없습니다."
            );
        }

        validatePositiveId(dto.getVehicleId(), "차량 ID");
        validateSpecification(dto);
        validateOperationStatus(dto.getOperationStatus());
    }

    private void validateSpecification(TractorDTO dto) {
        if (dto == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "트랙터 정보가 없습니다."
            );
        }

        if (dto.getTrafficSurveyClass() != null
                && (dto.getTrafficSurveyClass() < 1
                || dto.getTrafficSurveyClass() > 12)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "교통조사 차종은 1종부터 12종 사이여야 합니다."
            );
        }

        if (dto.getAxleCount() != null
                && (dto.getAxleCount() < 1
                || dto.getAxleCount() > 12)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "축수는 1부터 12 사이여야 합니다."
            );
        }

        if (dto.getMaxLoadTon() != null
                && dto.getMaxLoadTon().signum() < 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "최대 적재량은 0 이상이어야 합니다."
            );
        }

        if (dto.getGrossWeightTon() != null
                && dto.getGrossWeightTon().signum() < 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "총중량은 0 이상이어야 합니다."
            );
        }
    }

    private void validateOperationStatus(String operationStatus) {
        if (operationStatus == null || operationStatus.isBlank()) {
            return;
        }

        normalizeOperationStatus(operationStatus);
    }

    private String normalizeOperationStatus(String operationStatus) {
        if (operationStatus == null || operationStatus.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "트랙터 운행 상태가 비어 있습니다."
            );
        }

        String normalizedStatus = operationStatus
                .trim()
                .toUpperCase();

        if (!ALLOWED_OPERATION_STATUSES.contains(normalizedStatus)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "지원하지 않는 트랙터 운행 상태입니다: " + operationStatus
            );
        }

        return normalizedStatus;
    }

    private void applyDefaults(TractorDTO dto) {
        if (dto.getRequiresWeighing() == null) {
            dto.setRequiresWeighing(false);
        }

        if (dto.getSpecialTransport() == null) {
            dto.setSpecialTransport(false);
        }

        if (dto.getOperationStatus() == null
                || dto.getOperationStatus().isBlank()) {
            dto.setOperationStatus("AVAILABLE");
        } else {
            dto.setOperationStatus(
                    normalizeOperationStatus(dto.getOperationStatus())
            );
        }
    }

    private void validatePositiveId(Long id, String fieldName) {
        if (id == null || id <= 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    fieldName + "가 올바르지 않습니다."
            );
        }
    }

    private String normalizePlateNumber(String plateNumber) {
        if (plateNumber == null || plateNumber.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "번호판 값이 비어 있습니다."
            );
        }

        return plateNumber
                .replaceAll("\\s+", "")
                .trim();
    }
}