package aaa.tractor_p.controller;

import aaa.tractor_p.model.TractorDTO;
import aaa.tractor_p.service.TractorService;
import jakarta.annotation.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tractors")
public class TractorController {

    @Resource
    private TractorService service;

    /**
     * 트랙터 전체 조회
     *
     * GET /api/tractors
     */
    @GetMapping
    public List<TractorDTO> list() {
        return service.list();
    }

    /**
     * 사용 가능한 트랙터 조회
     *
     * GET /api/tractors/available
     */
    @GetMapping("/available")
    public List<TractorDTO> availableList() {
        return service.availableList();
    }

    /**
     * 트랙터 단건 조회
     *
     * GET /api/tractors/{tractorId}
     */
    @GetMapping("/{tractorId}")
    public TractorDTO detail(
            @PathVariable Long tractorId
    ) {
        return service.detail(tractorId);
    }

    /**
     * vehicle_id 기준 트랙터 조회
     *
     * GET /api/tractors/by-vehicle/{vehicleId}
     */
    @GetMapping("/by-vehicle/{vehicleId}")
    public TractorDTO findByVehicleId(
            @PathVariable Long vehicleId
    ) {
        return service.findByVehicleId(vehicleId);
    }

    /**
     * 번호판 기준 트랙터 조회
     *
     * GET /api/tractors/by-plate?plateNumber=...
     */
    @GetMapping("/by-plate")
    public TractorDTO findByPlateNumber(
            @RequestParam String plateNumber
    ) {
        return service.findByPlateNumber(plateNumber);
    }

    /**
     * 트랙터 등록
     *
     * POST /api/tractors
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TractorDTO create(
            @RequestBody TractorDTO dto
    ) {
        return service.create(dto);
    }

    /**
     * 트랙터 수정
     *
     * PUT /api/tractors/{tractorId}
     */
    @PutMapping("/{tractorId}")
    public TractorDTO update(
            @PathVariable Long tractorId,
            @RequestBody TractorDTO dto
    ) {
        return service.update(tractorId, dto);
    }

    /**
     * vehicle_id 기준 트랙터 정보 생성 또는 동기화
     *
     * PUT /api/tractors/by-vehicle/{vehicleId}
     */
    @PutMapping("/by-vehicle/{vehicleId}")
    public TractorDTO syncByVehicleId(
            @PathVariable Long vehicleId,
            @RequestBody TractorDTO dto
    ) {
        return service.syncByVehicleId(vehicleId, dto);
    }

    /**
     * 트랙터 운행 상태 변경
     *
     * PATCH /api/tractors/{tractorId}/status
     *
     * 요청 예:
     * {
     *   "operationStatus": "ASSIGNED"
     * }
     */
    @PatchMapping("/{tractorId}/status")
    public TractorDTO changeOperationStatus(
            @PathVariable Long tractorId,
            @RequestBody Map<String, String> request
    ) {
        return service.changeOperationStatus(
                tractorId,
                request.get("operationStatus")
        );
    }

    /**
     * vehicle_id 기준 트랙터 운행 상태 변경
     *
     * PATCH /api/tractors/by-vehicle/{vehicleId}/status
     */
    @PatchMapping("/by-vehicle/{vehicleId}/status")
    public TractorDTO changeOperationStatusByVehicleId(
            @PathVariable Long vehicleId,
            @RequestBody Map<String, String> request
    ) {
        return service.changeOperationStatusByVehicleId(
                vehicleId,
                request.get("operationStatus")
        );
    }

    /**
     * 트랙터 상세정보 삭제
     *
     * DELETE /api/tractors/{tractorId}
     */
    @DeleteMapping("/{tractorId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(
            @PathVariable Long tractorId
    ) {
        service.delete(tractorId);
    }
}