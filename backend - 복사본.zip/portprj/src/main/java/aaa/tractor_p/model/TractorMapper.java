package aaa.tractor_p.model;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface TractorMapper {

    /**
     * 트랙터 전체 조회
     */
    @Select("""
            SELECT
                t.tractor_id AS tractorId,
                t.vehicle_id AS vehicleId,
                t.tractor_no AS tractorNo,
                t.vehicle_structure AS vehicleStructure,
                t.traffic_survey_class AS trafficSurveyClass,
                t.axle_count AS axleCount,
                t.max_load_ton AS maxLoadTon,
                t.gross_weight_ton AS grossWeightTon,
                t.requires_weighing AS requiresWeighing,
                t.special_transport AS specialTransport,
                t.operation_status AS operationStatus,
                t.created_at AS createdAt,
                t.updated_at AS updatedAt
            FROM tractor t
            ORDER BY t.tractor_id DESC
            """)
    List<TractorDTO> list();

    /**
     * 트랙터 단건 조회
     */
    @Select("""
            SELECT
                t.tractor_id AS tractorId,
                t.vehicle_id AS vehicleId,
                t.tractor_no AS tractorNo,
                t.vehicle_structure AS vehicleStructure,
                t.traffic_survey_class AS trafficSurveyClass,
                t.axle_count AS axleCount,
                t.max_load_ton AS maxLoadTon,
                t.gross_weight_ton AS grossWeightTon,
                t.requires_weighing AS requiresWeighing,
                t.special_transport AS specialTransport,
                t.operation_status AS operationStatus,
                t.created_at AS createdAt,
                t.updated_at AS updatedAt
            FROM tractor t
            WHERE t.tractor_id = #{tractorId}
            """)
    TractorDTO detail(@Param("tractorId") Long tractorId);

    /**
     * vehicle_id 기준 트랙터 조회
     */
    @Select("""
            SELECT
                t.tractor_id AS tractorId,
                t.vehicle_id AS vehicleId,
                t.tractor_no AS tractorNo,
                t.vehicle_structure AS vehicleStructure,
                t.traffic_survey_class AS trafficSurveyClass,
                t.axle_count AS axleCount,
                t.max_load_ton AS maxLoadTon,
                t.gross_weight_ton AS grossWeightTon,
                t.requires_weighing AS requiresWeighing,
                t.special_transport AS specialTransport,
                t.operation_status AS operationStatus,
                t.created_at AS createdAt,
                t.updated_at AS updatedAt
            FROM tractor t
            WHERE t.vehicle_id = #{vehicleId}
            """)
    TractorDTO findByVehicleId(@Param("vehicleId") Long vehicleId);

    /**
     * 번호판 기준 트랙터 조회
     */
    @Select("""
            SELECT
                t.tractor_id AS tractorId,
                t.vehicle_id AS vehicleId,
                t.tractor_no AS tractorNo,
                t.vehicle_structure AS vehicleStructure,
                t.traffic_survey_class AS trafficSurveyClass,
                t.axle_count AS axleCount,
                t.max_load_ton AS maxLoadTon,
                t.gross_weight_ton AS grossWeightTon,
                t.requires_weighing AS requiresWeighing,
                t.special_transport AS specialTransport,
                t.operation_status AS operationStatus,
                t.created_at AS createdAt,
                t.updated_at AS updatedAt
            FROM tractor t
            JOIN vehicle v
              ON v.vehicle_id = t.vehicle_id
            WHERE REPLACE(v.plate_number, ' ', '') =
                  REPLACE(#{plateNumber}, ' ', '')
            LIMIT 1
            """)
    TractorDTO findByPlateNumber(@Param("plateNumber") String plateNumber);

    /**
     * 사용 가능한 트랙터 조회
     */
    @Select("""
            SELECT
                t.tractor_id AS tractorId,
                t.vehicle_id AS vehicleId,
                t.tractor_no AS tractorNo,
                t.vehicle_structure AS vehicleStructure,
                t.traffic_survey_class AS trafficSurveyClass,
                t.axle_count AS axleCount,
                t.max_load_ton AS maxLoadTon,
                t.gross_weight_ton AS grossWeightTon,
                t.requires_weighing AS requiresWeighing,
                t.special_transport AS specialTransport,
                t.operation_status AS operationStatus,
                t.created_at AS createdAt,
                t.updated_at AS updatedAt
            FROM tractor t
            JOIN vehicle v
              ON v.vehicle_id = t.vehicle_id
            WHERE t.operation_status = 'AVAILABLE'
              AND COALESCE(v.is_registered, FALSE) = TRUE
              AND NOT EXISTS (
                  SELECT 1
                  FROM work_order wo
                  WHERE wo.tractor_vehicle_id = t.vehicle_id
                    AND wo.work_status IN (
                        'DISPATCH_WAITING',
                        'APPROVED',
                        'GATE_IN',
                        'IN_PROGRESS'
                    )
              )
            ORDER BY t.tractor_id ASC
            """)
    List<TractorDTO> findAvailableTractors();

    /**
     * vehicle_id 중복 확인
     */
    @Select("""
            SELECT COUNT(*)
            FROM tractor
            WHERE vehicle_id = #{vehicleId}
            """)
    int countByVehicleId(@Param("vehicleId") Long vehicleId);

    /**
     * 트랙터 등록
     */
    @Insert("""
            INSERT INTO tractor (
                vehicle_id,
                tractor_no,
                vehicle_structure,
                traffic_survey_class,
                axle_count,
                max_load_ton,
                gross_weight_ton,
                requires_weighing,
                special_transport,
                operation_status,
                created_at,
                updated_at
            )
            VALUES (
                #{vehicleId},
                #{tractorNo},
                #{vehicleStructure},
                #{trafficSurveyClass},
                #{axleCount},
                #{maxLoadTon},
                #{grossWeightTon},
                COALESCE(#{requiresWeighing}, FALSE),
                COALESCE(#{specialTransport}, FALSE),
                COALESCE(#{operationStatus}, 'AVAILABLE'),
                CURRENT_TIMESTAMP,
                CURRENT_TIMESTAMP
            )
            """)
    @Options(
            useGeneratedKeys = true,
            keyProperty = "tractorId",
            keyColumn = "tractor_id"
    )
    int insert(TractorDTO dto);

    /**
     * 트랙터 수정
     */
    @Update("""
            UPDATE tractor
            SET
                tractor_no = #{tractorNo},
                vehicle_structure = #{vehicleStructure},
                traffic_survey_class = #{trafficSurveyClass},
                axle_count = #{axleCount},
                max_load_ton = #{maxLoadTon},
                gross_weight_ton = #{grossWeightTon},
                requires_weighing = COALESCE(#{requiresWeighing}, FALSE),
                special_transport = COALESCE(#{specialTransport}, FALSE),
                operation_status = COALESCE(#{operationStatus}, operation_status),
                updated_at = CURRENT_TIMESTAMP
            WHERE tractor_id = #{tractorId}
            """)
    int update(TractorDTO dto);

    /**
     * 차량 ID 기준 트랙터 제원 동기화
     */
    @Update("""
            UPDATE tractor
            SET
                tractor_no = #{tractorNo},
                vehicle_structure = #{vehicleStructure},
                traffic_survey_class = #{trafficSurveyClass},
                axle_count = #{axleCount},
                max_load_ton = #{maxLoadTon},
                gross_weight_ton = #{grossWeightTon},
                requires_weighing = COALESCE(#{requiresWeighing}, FALSE),
                special_transport = COALESCE(#{specialTransport}, FALSE),
                updated_at = CURRENT_TIMESTAMP
            WHERE vehicle_id = #{vehicleId}
            """)
    int updateByVehicleId(TractorDTO dto);

    /**
     * 트랙터 운행 상태 변경
     */
    @Update("""
            UPDATE tractor
            SET
                operation_status = #{operationStatus},
                updated_at = CURRENT_TIMESTAMP
            WHERE tractor_id = #{tractorId}
            """)
    int updateOperationStatus(
            @Param("tractorId") Long tractorId,
            @Param("operationStatus") String operationStatus
    );

    /**
     * vehicle_id 기준 트랙터 운행 상태 변경
     */
    @Update("""
            UPDATE tractor
            SET
                operation_status = #{operationStatus},
                updated_at = CURRENT_TIMESTAMP
            WHERE vehicle_id = #{vehicleId}
            """)
    int updateOperationStatusByVehicleId(
            @Param("vehicleId") Long vehicleId,
            @Param("operationStatus") String operationStatus
    );

    /**
     * 트랙터 삭제
     */
    @Delete("""
            DELETE FROM tractor
            WHERE tractor_id = #{tractorId}
            """)
    int delete(@Param("tractorId") Long tractorId);
    @Delete("""
        DELETE FROM tractor
        WHERE vehicle_id = #{vehicleId}
        """)
    int deleteByVehicleId(@Param("vehicleId") Long vehicleId);
}