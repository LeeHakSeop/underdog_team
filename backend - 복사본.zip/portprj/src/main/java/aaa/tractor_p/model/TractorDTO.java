package aaa.tractor_p.model;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class TractorDTO {

    private Long tractorId;
    private Long vehicleId;

    private String tractorNo;
    private String vehicleStructure;

    private Integer trafficSurveyClass;
    private Integer axleCount;

    private BigDecimal maxLoadTon;
    private BigDecimal grossWeightTon;

    private Boolean requiresWeighing;
    private Boolean specialTransport;

    private String operationStatus;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}