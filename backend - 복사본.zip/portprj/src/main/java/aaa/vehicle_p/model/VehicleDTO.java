package aaa.vehicle_p.model;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VehicleDTO {

    // =========================
    // 기본 정보
    // =========================
    private Long vehicleId;

    private String plateNumber;

    private String vehicleType;

    private String tonnage;

    private Boolean isRegistered;

    private String vehicleStatus;

    private String tractorNo;

    private String chassisNo;

    private Long carrierId;

    private Long userId;

    private Long driverId;

    // =========================
    // STEP 1 - 자동 야드배정
    // =========================

    /** 교통조사 차종(1~12) */
    private Integer trafficSurveyClass;

    /** 축수 */
    private Integer axleCount;

    /** 최대 적재중량(톤) */
    private BigDecimal maxLoadTon;

    /** 총중량(톤) */
    private BigDecimal grossWeightTon;

    /** 차량 구조(TRUCK, TRACTOR, TRAILER 등) */
    private String vehicleStructure;

    /** 트레일러 연결방식(SEMI, FULL, NONE) */
    private String trailerConnectionType;

    /** 계근 대상 여부 */
    private Boolean requiresWeighing;

    /** 특수운송 여부 */
    private Boolean specialTransport;
}