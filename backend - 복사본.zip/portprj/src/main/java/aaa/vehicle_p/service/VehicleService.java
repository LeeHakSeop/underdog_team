package aaa.vehicle_p.service;

import aaa.driver_p.model.DriverDTO;
import aaa.driver_p.model.DriverMapper;
import aaa.tractor_p.model.TractorDTO;
import aaa.tractor_p.model.TractorMapper;
import aaa.trailer_p.model.TrailerDTO;
import aaa.trailer_p.model.TrailerMapper;
import aaa.user_p.model.UserMapper;
import aaa.vehicle_p.model.TractorVehicleInfoDTO;
import aaa.vehicle_p.model.VehicleDTO;
import aaa.vehicle_p.model.VehicleMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class VehicleService {

    @Resource
    private VehicleMapper vehicleMapper;

    @Resource
    private DriverMapper driverMapper;

    @Resource
    private UserMapper userMapper;

    @Resource
    private TractorMapper tractorMapper;

    @Resource
    private TrailerMapper trailerMapper;

    @Transactional(readOnly = true)
    public List<VehicleDTO> list() {
        return vehicleMapper.list();
    }

    @Transactional(readOnly = true)
    public VehicleDTO detail(Long vehicleId) {
        return vehicleMapper.detail(vehicleId);
    }

    @Transactional(readOnly = true)
    public TractorVehicleInfoDTO findTractorInfo(
            String plateNumber
    ) {
        if (plateNumber == null || plateNumber.isBlank()) {
            throw new IllegalArgumentException(
                    "차량번호는 필수입니다."
            );
        }

        return vehicleMapper.findTractorInfoByPlateNumber(
                normalizePlateNumber(plateNumber)
        );
    }

    @Transactional(readOnly = true)
    public List<VehicleDTO> findByCarrierId(
            Long carrierId
    ) {
        return vehicleMapper.findByCarrierId(carrierId);
    }

    @Transactional(readOnly = true)
    public VehicleDTO findByDriverId(
            Long driverId
    ) {
        return vehicleMapper.findByDriverId(driverId);
    }

    /**
     * vehicle 등록과 차량 유형별 상세 테이블 등록을
     * 하나의 트랜잭션으로 처리한다.
     */
    @Transactional
    public int insert(VehicleDTO dto) {
        validateInsert(dto);

        dto.setPlateNumber(
                normalizePlateNumber(dto.getPlateNumber())
        );
        dto.setVehicleType(
                normalizeVehicleType(dto.getVehicleType())
        );

        if (vehicleMapper.findByPlateNumber(
                dto.getPlateNumber()
        ) != null) {
            throw new IllegalArgumentException(
                    "이미 등록된 차량번호입니다."
            );
        }

        dto.setIsRegistered(false);
        dto.setVehicleStatus("승인대기");

        int inserted = vehicleMapper.insert(dto);

        if (inserted != 1) {
            throw new IllegalStateException(
                    "차량 정보를 등록하지 못했습니다."
            );
        }

        /*
         * VehicleMapper.insert에서 생성키를 DTO에 넣지 않는
         * 기존 구현도 고려하여 번호판으로 vehicleId를 다시 조회한다.
         */
        if (dto.getVehicleId() == null) {
            VehicleDTO saved =
                    vehicleMapper.findByPlateNumber(
                            dto.getPlateNumber()
                    );

            if (saved == null
                    || saved.getVehicleId() == null) {
                throw new IllegalStateException(
                        "등록된 차량의 vehicleId를 확인하지 못했습니다."
                );
            }

            dto.setVehicleId(saved.getVehicleId());
        }

        synchronizeVehicleDetail(dto);

        return inserted;
    }

    /**
     * vehicle 수정과 차량 유형별 상세 테이블 수정을
     * 하나의 트랜잭션으로 처리한다.
     */
    @Transactional
    public int update(VehicleDTO dto) {
        validateUpdate(dto);

        VehicleDTO current =
                vehicleMapper.detail(dto.getVehicleId());

        if (current == null) {
            throw new IllegalArgumentException(
                    "차량 정보를 찾을 수 없습니다."
            );
        }

        dto.setPlateNumber(
                normalizePlateNumber(dto.getPlateNumber())
        );
        dto.setVehicleType(
                normalizeVehicleType(dto.getVehicleType())
        );

        VehicleDTO samePlateVehicle =
                vehicleMapper.findByPlateNumber(
                        dto.getPlateNumber()
                );

        if (samePlateVehicle != null
                && !samePlateVehicle.getVehicleId()
                .equals(dto.getVehicleId())) {
            throw new IllegalArgumentException(
                    "이미 등록된 차량번호입니다."
            );
        }

        if (dto.getIsRegistered() == null) {
            dto.setIsRegistered(
                    Boolean.TRUE.equals(
                            current.getIsRegistered()
                    )
            );
        }

        if (dto.getVehicleStatus() == null
                || dto.getVehicleStatus().isBlank()) {
            dto.setVehicleStatus(
                    current.getVehicleStatus()
            );
        }

        int updated = vehicleMapper.update(dto);

        if (updated != 1) {
            throw new IllegalStateException(
                    "차량 정보를 수정하지 못했습니다."
            );
        }

        synchronizeVehicleDetail(dto);

        return updated;
    }

    /**
     * tractor와 trailer 모두 vehicle_id FK에
     * ON DELETE CASCADE가 적용되어 있으므로
     * vehicle 삭제 시 상세정보도 자동 삭제된다.
     */
    @Transactional
    public int delete(Long vehicleId) {
        validatePositiveId(vehicleId, "차량 ID");

        VehicleDTO vehicle =
                vehicleMapper.detail(vehicleId);

        if (vehicle == null) {
            throw new IllegalArgumentException(
                    "차량 정보를 찾을 수 없습니다."
            );
        }

        int deleted =
                vehicleMapper.delete(vehicleId);

        if (deleted != 1) {
            throw new IllegalStateException(
                    "차량 정보를 삭제하지 못했습니다."
            );
        }

        return deleted;
    }

    @Transactional
    public int updateApproval(
            Long vehicleId,
            VehicleDTO dto
    ) {
        validatePositiveId(vehicleId, "차량 ID");

        VehicleDTO vehicle =
                vehicleMapper.detail(vehicleId);

        if (vehicle == null) {
            throw new IllegalArgumentException(
                    "차량 정보를 찾을 수 없습니다."
            );
        }

        if (vehicle.getDriverId() == null) {
            throw new IllegalArgumentException(
                    "배정 기사가 없는 차량입니다."
            );
        }

        DriverDTO driver =
                driverMapper.detail(vehicle.getDriverId());

        if (driver == null) {
            throw new IllegalArgumentException(
                    "배정된 기사 정보를 찾을 수 없습니다."
            );
        }

        boolean approved =
                dto != null
                        && Boolean.TRUE.equals(
                        dto.getIsRegistered()
                );

        String vehicleStatus =
                approved ? "정상" : "승인거절";

        int updated =
                vehicleMapper.updateApproval(
                        vehicleId,
                        approved,
                        vehicleStatus
                );

        if (updated != 1) {
            return updated;
        }

        driverMapper.updateApprovalByDriverId(
                driver.getDriverId(),
                true,
                approved
        );

        if (driver.getUserId() != null) {
            userMapper.updateStatus(
                    driver.getUserId(),
                    approved
                            ? "ACTIVE"
                            : "CARRIER_APPROVED"
            );
        }

        return updated;
    }

    /**
     * 차량 유형에 따라 상세 테이블을 정합성 있게 유지한다.
     *
     * TRACTOR:
     * - tractor 생성 또는 수정
     * - 잘못 남은 trailer 삭제
     *
     * TRAILER:
     * - trailer 생성 또는 수정
     * - 잘못 남은 tractor 삭제
     *
     * CARGO:
     * - tractor와 trailer 상세정보 모두 삭제
     */
    private void synchronizeVehicleDetail(
            VehicleDTO vehicle
    ) {
        if (vehicle == null
                || vehicle.getVehicleId() == null) {
            throw new IllegalArgumentException(
                    "차량 상세정보 동기화에 vehicleId가 필요합니다."
            );
        }

        String vehicleType =
                normalizeVehicleType(
                        vehicle.getVehicleType()
                );

        vehicle.setVehicleType(vehicleType);

        if ("TRACTOR".equals(vehicleType)) {
            deleteTrailerDetailIfExists(
                    vehicle.getVehicleId()
            );
            syncTractorDetail(vehicle);
            return;
        }

        if ("TRAILER".equals(vehicleType)) {
            deleteTractorDetailIfExists(
                    vehicle.getVehicleId()
            );
            syncTrailerDetail(vehicle);
            return;
        }

        deleteTractorDetailIfExists(
                vehicle.getVehicleId()
        );
        deleteTrailerDetailIfExists(
                vehicle.getVehicleId()
        );
    }

    /**
     * vehicle_type이 TRACTOR인 차량의 상세정보를
     * tractor 테이블에 생성 또는 수정한다.
     */
    private void syncTractorDetail(
            VehicleDTO vehicle
    ) {
        validateVehicleSpecification(vehicle);

        TractorDTO existing =
                tractorMapper.findByVehicleId(
                        vehicle.getVehicleId()
                );

        TractorDTO tractor =
                new TractorDTO();

        tractor.setVehicleId(
                vehicle.getVehicleId()
        );
        tractor.setTractorNo(
                vehicle.getTractorNo()
        );
        tractor.setVehicleStructure(
                normalizeStructure(
                        vehicle.getVehicleStructure(),
                        "TRACTOR"
                )
        );
        tractor.setTrafficSurveyClass(
                vehicle.getTrafficSurveyClass()
        );
        tractor.setAxleCount(
                vehicle.getAxleCount()
        );
        tractor.setMaxLoadTon(
                vehicle.getMaxLoadTon()
        );
        tractor.setGrossWeightTon(
                vehicle.getGrossWeightTon()
        );
        tractor.setRequiresWeighing(
                Boolean.TRUE.equals(
                        vehicle.getRequiresWeighing()
                )
        );
        tractor.setSpecialTransport(
                Boolean.TRUE.equals(
                        vehicle.getSpecialTransport()
                )
        );

        if (existing == null) {
            tractor.setOperationStatus("AVAILABLE");

            int inserted =
                    tractorMapper.insert(tractor);

            if (inserted != 1) {
                throw new IllegalStateException(
                        "트랙터 상세정보를 등록하지 못했습니다."
                );
            }

            return;
        }

        tractor.setTractorId(
                existing.getTractorId()
        );
        tractor.setOperationStatus(
                existing.getOperationStatus()
        );

        int updated =
                tractorMapper.updateByVehicleId(
                        tractor
                );

        if (updated != 1) {
            throw new IllegalStateException(
                    "트랙터 상세정보를 수정하지 못했습니다."
            );
        }
    }

    /**
     * vehicle_type이 TRAILER인 차량의 상세정보를
     * trailer 테이블에 생성 또는 수정한다.
     */
    private void syncTrailerDetail(
            VehicleDTO vehicle
    ) {
        validateVehicleSpecification(vehicle);

        TrailerDTO existing =
                trailerMapper.findByVehicleId(
                        vehicle.getVehicleId()
                );

        TrailerDTO trailer =
                new TrailerDTO();

        trailer.setVehicleId(
                vehicle.getVehicleId()
        );

        /*
         * 현재 vehicle에는 trailer_no 컬럼이 없으므로
         * 번호판을 트레일러 번호로 사용한다.
         */
        trailer.setTrailerNo(
                vehicle.getPlateNumber()
        );

        trailer.setTrailerStructure(
                normalizeStructure(
                        vehicle.getVehicleStructure(),
                        "TRAILER"
                )
        );
        trailer.setTrafficSurveyClass(
                vehicle.getTrafficSurveyClass()
        );
        trailer.setAxleCount(
                vehicle.getAxleCount()
        );
        trailer.setMaxLoadTon(
                vehicle.getMaxLoadTon()
        );
        trailer.setGrossWeightTon(
                vehicle.getGrossWeightTon()
        );
        trailer.setRequiresWeighing(
                Boolean.TRUE.equals(
                        vehicle.getRequiresWeighing()
                )
        );

        /*
         * 현재 VehicleDTO에 위험물·냉동 차량 전용 필드가 없으므로
         * 기존 trailer 값은 유지하고 신규 등록은 false로 처리한다.
         */
        trailer.setDangerousGoodsVehicle(
                existing != null
                        && Boolean.TRUE.equals(
                        existing.getDangerousGoodsVehicle()
                )
        );
        trailer.setReeferVehicle(
                existing != null
                        && Boolean.TRUE.equals(
                        existing.getReeferVehicle()
                )
        );

        trailer.setSpecialTransport(
                Boolean.TRUE.equals(
                        vehicle.getSpecialTransport()
                )
        );
        trailer.setConnectionType(
                normalizeNullableText(
                        vehicle.getTrailerConnectionType()
                )
        );

        if (existing == null) {
            trailer.setOperationStatus("AVAILABLE");

            int inserted =
                    trailerMapper.insert(trailer);

            if (inserted != 1) {
                throw new IllegalStateException(
                        "트레일러 상세정보를 등록하지 못했습니다."
                );
            }

            return;
        }

        trailer.setTrailerId(
                existing.getTrailerId()
        );
        trailer.setOperationStatus(
                existing.getOperationStatus()
        );

        int updated =
                trailerMapper.updateByVehicleId(
                        trailer
                );

        if (updated != 1) {
            throw new IllegalStateException(
                    "트레일러 상세정보를 수정하지 못했습니다."
            );
        }
    }

    private void deleteTractorDetailIfExists(
            Long vehicleId
    ) {
        TractorDTO existing =
                tractorMapper.findByVehicleId(vehicleId);

        if (existing != null) {
            tractorMapper.deleteByVehicleId(vehicleId);
        }
    }

    private void deleteTrailerDetailIfExists(
            Long vehicleId
    ) {
        TrailerDTO existing =
                trailerMapper.findByVehicleId(vehicleId);

        if (existing != null) {
            trailerMapper.deleteByVehicleId(vehicleId);
        }
    }

    private void validateInsert(VehicleDTO dto) {
        if (dto == null) {
            throw new IllegalArgumentException(
                    "차량 정보는 필수입니다."
            );
        }

        if (dto.getPlateNumber() == null
                || dto.getPlateNumber().isBlank()) {
            throw new IllegalArgumentException(
                    "차량번호는 필수입니다."
            );
        }

        if (dto.getVehicleType() == null
                || dto.getVehicleType().isBlank()) {
            throw new IllegalArgumentException(
                    "차량종류는 필수입니다."
            );
        }

        String normalizedType =
                normalizeVehicleType(
                        dto.getVehicleType()
                );

        if (!isSupportedVehicleType(normalizedType)) {
            throw new IllegalArgumentException(
                    "지원하지 않는 차량종류입니다: "
                            + dto.getVehicleType()
            );
        }

        dto.setVehicleType(normalizedType);

        if (!isTractor(normalizedType)
                && (dto.getTonnage() == null
                || dto.getTonnage().isBlank())) {
            throw new IllegalArgumentException(
                    "톤수는 필수입니다."
            );
        }

        if (dto.getDriverId() == null) {
            throw new IllegalArgumentException(
                    "배정 기사는 필수입니다."
            );
        }

        if (dto.getCarrierId() == null) {
            throw new IllegalArgumentException(
                    "운송사 ID는 필수입니다."
            );
        }

        if (isTractor(normalizedType)
                || isTrailer(normalizedType)) {
            validateVehicleSpecification(dto);
        }
    }

    private void validateUpdate(VehicleDTO dto) {
        if (dto == null
                || dto.getVehicleId() == null) {
            throw new IllegalArgumentException(
                    "차량 ID는 필수입니다."
            );
        }

        validateInsert(dto);
    }

    private void validateVehicleSpecification(
            VehicleDTO dto
    ) {
        if (dto.getTrafficSurveyClass() != null
                && (
                dto.getTrafficSurveyClass() < 1
                        || dto.getTrafficSurveyClass() > 12
        )) {
            throw new IllegalArgumentException(
                    "교통조사 차종은 1종부터 12종 사이여야 합니다."
            );
        }

        if (dto.getAxleCount() != null
                && (
                dto.getAxleCount() < 1
                        || dto.getAxleCount() > 12
        )) {
            throw new IllegalArgumentException(
                    "축수는 1부터 12 사이여야 합니다."
            );
        }

        if (dto.getMaxLoadTon() != null
                && dto.getMaxLoadTon().signum() < 0) {
            throw new IllegalArgumentException(
                    "최대 적재량은 0 이상이어야 합니다."
            );
        }

        if (dto.getGrossWeightTon() != null
                && dto.getGrossWeightTon().signum() < 0) {
            throw new IllegalArgumentException(
                    "총중량은 0 이상이어야 합니다."
            );
        }
    }

    private boolean isTractor(String vehicleType) {
        return "TRACTOR".equalsIgnoreCase(
                vehicleType == null
                        ? ""
                        : vehicleType.trim()
        )
                || "트랙터".equals(
                vehicleType == null
                        ? ""
                        : vehicleType.trim()
        );
    }

    private boolean isTrailer(String vehicleType) {
        return "TRAILER".equalsIgnoreCase(
                vehicleType == null
                        ? ""
                        : vehicleType.trim()
        )
                || "트레일러".equals(
                vehicleType == null
                        ? ""
                        : vehicleType.trim()
        );
    }

    private boolean isCargo(String vehicleType) {
        return "CARGO".equalsIgnoreCase(
                vehicleType == null
                        ? ""
                        : vehicleType.trim()
        )
                || "카고".equals(
                vehicleType == null
                        ? ""
                        : vehicleType.trim()
        );
    }

    private boolean isSupportedVehicleType(
            String vehicleType
    ) {
        return isTractor(vehicleType)
                || isTrailer(vehicleType)
                || isCargo(vehicleType);
    }

    private String normalizeVehicleType(
            String vehicleType
    ) {
        if (isTractor(vehicleType)) {
            return "TRACTOR";
        }

        if (isTrailer(vehicleType)) {
            return "TRAILER";
        }

        if (isCargo(vehicleType)) {
            return "CARGO";
        }

        return vehicleType == null
                ? null
                : vehicleType.trim().toUpperCase();
    }

    private String normalizePlateNumber(
            String plateNumber
    ) {
        return plateNumber == null
                ? null
                : plateNumber
                .replaceAll("\\s+", "")
                .trim();
    }

    private String normalizeStructure(
            String value,
            String defaultValue
    ) {
        if (value == null || value.isBlank()) {
            return defaultValue;
        }

        return value.trim().toUpperCase();
    }

    private String normalizeNullableText(
            String value
    ) {
        if (value == null || value.isBlank()) {
            return null;
        }

        return value.trim().toUpperCase();
    }

    private void validatePositiveId(
            Long id,
            String fieldName
    ) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException(
                    fieldName + "가 올바르지 않습니다."
            );
        }
    }
}