package aaa.container_p.model;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class ContainerDTO {

    private Long containerId;

    // 기존 기본 정보
    private String containerNumber;
    private String containerSize;
    private String containerLocation;

    // 기존 위치 정보
    private Long sectorId;
    private String block;
    private String bay;
    private String rowNo;

    // 기존 반출·봉인·선사 정보
    private Boolean canExit;
    private String sealNumber;
    private String shippingLine;

    // ISO 및 화물 분류 정보
    private String isoSizeTypeCode;
    private String cargoFlowType;
    private String loadStatus;
    private String containerType;
    private Boolean checkDigitValid;

    // 중량 및 특수조건 정보
    private BigDecimal grossWeightTon;
    private Boolean reefer;
    private Boolean dangerousGoods;
    private String dangerousGoodsClass;
    private String unNumber;
    private Boolean oog;
    private Boolean heavyCargo;
    private Boolean inspectionRequired;
    private String holdStatus;
    private Boolean damaged;
}