package aaa.container_p.model;

import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ContainerMapper {

    @Select("""
        SELECT
            container_id AS containerId,
            container_number AS containerNumber,
            container_size AS containerSize,
            container_location AS containerLocation,
            sector_id AS sectorId,
            block,
            bay,
            row_no AS rowNo,
            can_exit AS canExit,
            seal_number AS sealNumber,
            shipping_line AS shippingLine,
            iso_size_type_code AS isoSizeTypeCode,
            cargo_flow_type AS cargoFlowType,
            load_status AS loadStatus,
            container_type AS containerType,
            check_digit_valid AS checkDigitValid,
            gross_weight_ton AS grossWeightTon,
            reefer,
            dangerous_goods AS dangerousGoods,
            dangerous_goods_class AS dangerousGoodsClass,
            un_number AS unNumber,
            oog,
            heavy_cargo AS heavyCargo,
            inspection_required AS inspectionRequired,
            hold_status AS holdStatus,
            damaged
        FROM container
        ORDER BY container_id DESC
        """)
    List<ContainerDTO> list();

    @Select("""
        SELECT
            container_id AS containerId,
            container_number AS containerNumber,
            container_size AS containerSize,
            container_location AS containerLocation,
            sector_id AS sectorId,
            block,
            bay,
            row_no AS rowNo,
            can_exit AS canExit,
            seal_number AS sealNumber,
            shipping_line AS shippingLine,
            iso_size_type_code AS isoSizeTypeCode,
            cargo_flow_type AS cargoFlowType,
            load_status AS loadStatus,
            container_type AS containerType,
            check_digit_valid AS checkDigitValid,
            gross_weight_ton AS grossWeightTon,
            reefer,
            dangerous_goods AS dangerousGoods,
            dangerous_goods_class AS dangerousGoodsClass,
            un_number AS unNumber,
            oog,
            heavy_cargo AS heavyCargo,
            inspection_required AS inspectionRequired,
            hold_status AS holdStatus,
            damaged
        FROM container
        WHERE container_id = #{containerId}
        """)
    ContainerDTO detail(@Param("containerId") Long containerId);

    @Select("""
        SELECT
            container_id AS containerId,
            container_number AS containerNumber,
            container_size AS containerSize,
            container_location AS containerLocation,
            sector_id AS sectorId,
            block,
            bay,
            row_no AS rowNo,
            can_exit AS canExit,
            seal_number AS sealNumber,
            shipping_line AS shippingLine,
            iso_size_type_code AS isoSizeTypeCode,
            cargo_flow_type AS cargoFlowType,
            load_status AS loadStatus,
            container_type AS containerType,
            check_digit_valid AS checkDigitValid,
            gross_weight_ton AS grossWeightTon,
            reefer,
            dangerous_goods AS dangerousGoods,
            dangerous_goods_class AS dangerousGoodsClass,
            un_number AS unNumber,
            oog,
            heavy_cargo AS heavyCargo,
            inspection_required AS inspectionRequired,
            hold_status AS holdStatus,
            damaged
        FROM container
        WHERE container_number = #{containerNumber}
        """)
    ContainerDTO findByContainerNumber(
            @Param("containerNumber") String containerNumber
    );

    @Insert("""
        INSERT INTO container (
            container_number,
            container_size,
            container_location,
            sector_id,
            block,
            bay,
            row_no,
            can_exit,
            seal_number,
            shipping_line,
            iso_size_type_code,
            cargo_flow_type,
            load_status,
            container_type,
            check_digit_valid,
            gross_weight_ton,
            reefer,
            dangerous_goods,
            dangerous_goods_class,
            un_number,
            oog,
            heavy_cargo,
            inspection_required,
            hold_status,
            damaged
        ) VALUES (
            #{containerNumber},
            #{containerSize},
            #{containerLocation},
            #{sectorId},
            #{block},
            #{bay},
            #{rowNo},
            #{canExit},
            #{sealNumber},
            #{shippingLine},
            #{isoSizeTypeCode},
            #{cargoFlowType},
            #{loadStatus},
            #{containerType},
            #{checkDigitValid},
            #{grossWeightTon},
            COALESCE(#{reefer}, FALSE),
            COALESCE(#{dangerousGoods}, FALSE),
            #{dangerousGoodsClass},
            #{unNumber},
            COALESCE(#{oog}, FALSE),
            COALESCE(#{heavyCargo}, FALSE),
            COALESCE(#{inspectionRequired}, FALSE),
            COALESCE(#{holdStatus}, 'NONE'),
            COALESCE(#{damaged}, FALSE)
        )
        """)
    @Options(
            useGeneratedKeys = true,
            keyProperty = "containerId",
            keyColumn = "container_id"
    )
    int insert(ContainerDTO dto);

    @Update("""
        UPDATE container
        SET
            container_number = #{containerNumber},
            container_size = #{containerSize},
            container_location = #{containerLocation},
            sector_id = #{sectorId},
            block = #{block},
            bay = #{bay},
            row_no = #{rowNo},
            can_exit = #{canExit},
            seal_number = #{sealNumber},
            shipping_line = #{shippingLine},
            iso_size_type_code = #{isoSizeTypeCode},
            cargo_flow_type = #{cargoFlowType},
            load_status = #{loadStatus},
            container_type = #{containerType},
            check_digit_valid = #{checkDigitValid},
            gross_weight_ton = #{grossWeightTon},
            reefer = COALESCE(#{reefer}, FALSE),
            dangerous_goods = COALESCE(#{dangerousGoods}, FALSE),
            dangerous_goods_class = #{dangerousGoodsClass},
            un_number = #{unNumber},
            oog = COALESCE(#{oog}, FALSE),
            heavy_cargo = COALESCE(#{heavyCargo}, FALSE),
            inspection_required = COALESCE(#{inspectionRequired}, FALSE),
            hold_status = COALESCE(#{holdStatus}, 'NONE'),
            damaged = COALESCE(#{damaged}, FALSE)
        WHERE container_id = #{containerId}
        """)
    int update(ContainerDTO dto);

    @Delete("""
        DELETE FROM container
        WHERE container_id = #{containerId}
        """)
    int delete(@Param("containerId") Long containerId);

    @Select("""
        SELECT COUNT(*)
        FROM work_order
        WHERE container_id = #{containerId}
        """)
    int countWorkOrders(@Param("containerId") Long containerId);

    @Select("""
        SELECT EXISTS (
            SELECT 1
            FROM yard_sector
            WHERE sector_id = #{sectorId}
        )
        """)
    boolean existsYardSector(@Param("sectorId") Long sectorId);

    @Update("""
        UPDATE container
        SET can_exit = #{canExit}
        WHERE container_id = #{containerId}
        """)
    int updateCanExit(
            @Param("containerId") Long containerId,
            @Param("canExit") boolean canExit
    );

    @Update("""
        UPDATE container
        SET
            sector_id = #{sectorId},
            container_location = #{containerLocation},
            block = #{block},
            bay = #{bay},
            row_no = #{rowNo}
        WHERE container_id = #{containerId}
        """)
    int updateLocation(
            @Param("containerId") Long containerId,
            @Param("sectorId") Long sectorId,
            @Param("containerLocation") String containerLocation,
            @Param("block") String block,
            @Param("bay") String bay,
            @Param("rowNo") String rowNo
    );
}