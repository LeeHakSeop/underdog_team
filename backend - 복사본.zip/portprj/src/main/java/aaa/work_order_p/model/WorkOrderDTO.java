package aaa.work_order_p.model;

import java.time.LocalDateTime;
import lombok.Data;

@Data
public class WorkOrderDTO {

    private Long workOrderId;
    private String workType;

    private Long vehicleId;
    private Long tractorVehicleId;
    private Long trailerVehicleId;

    private Long driverId;
    private Long containerId;

    private LocalDateTime reservedTime;

    private String workStatus;
    private Boolean isApproved;

    // 자동 야드배정
    private Long assignedSectorId;
    private String assignmentReason;
    private String assignmentMethod;
    private LocalDateTime assignedAt;
}