-- WBS 8.0 / 8.1 DB 적용 검증
-- 정상 기준:
-- 1) tractor_count = vehicle_tractor_count
-- 2) trailer_count = vehicle_trailer_count
-- 3) tractor_missing_count = 0
-- 4) trailer_missing_count = 0
-- 5) wrong_tractor_type_count = 0
-- 6) wrong_trailer_type_count = 0

SELECT COUNT(*) AS tractor_count
FROM public.tractor;

SELECT COUNT(*) AS trailer_count
FROM public.trailer;

SELECT vehicle_type, COUNT(*) AS vehicle_count
FROM public.vehicle
GROUP BY vehicle_type
ORDER BY vehicle_type;

SELECT COUNT(*) AS vehicle_tractor_count
FROM public.vehicle
WHERE UPPER(TRIM(COALESCE(vehicle_type, ''))) = 'TRACTOR';

SELECT COUNT(*) AS vehicle_trailer_count
FROM public.vehicle
WHERE UPPER(TRIM(COALESCE(vehicle_type, ''))) = 'TRAILER';

SELECT COUNT(*) AS tractor_missing_count
FROM public.vehicle v
LEFT JOIN public.tractor t
       ON t.vehicle_id = v.vehicle_id
WHERE UPPER(TRIM(COALESCE(v.vehicle_type, ''))) = 'TRACTOR'
  AND t.vehicle_id IS NULL;

SELECT COUNT(*) AS trailer_missing_count
FROM public.vehicle v
LEFT JOIN public.trailer t
       ON t.vehicle_id = v.vehicle_id
WHERE UPPER(TRIM(COALESCE(v.vehicle_type, ''))) = 'TRAILER'
  AND t.vehicle_id IS NULL;

SELECT COUNT(*) AS wrong_tractor_type_count
FROM public.tractor t
JOIN public.vehicle v
  ON v.vehicle_id = t.vehicle_id
WHERE UPPER(TRIM(COALESCE(v.vehicle_type, ''))) <> 'TRACTOR';

SELECT COUNT(*) AS wrong_trailer_type_count
FROM public.trailer t
JOIN public.vehicle v
  ON v.vehicle_id = t.vehicle_id
WHERE UPPER(TRIM(COALESCE(v.vehicle_type, ''))) <> 'TRAILER';
