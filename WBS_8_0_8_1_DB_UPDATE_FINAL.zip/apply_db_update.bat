@echo off
setlocal

title Port Project DB Update - WBS 8.0 / 8.1

set HOST=localhost
set PORT=5432
set USER=postgres
set DB=portprj

echo.
set /p PASSWORD=PostgreSQL Password: 
set PGPASSWORD=%PASSWORD%

echo.
echo ========================================
echo WBS 8.0 / 8.1 DB Update Start
echo ========================================

for %%f in (
20260804_create_tractor_table.sql
20260804_create_trailer_table.sql
20260804_normalize_vehicle_type.sql
20260804_migrate_tractor.sql
20260804_migrate_trailer.sql
20260804_verify.sql
) do (
    echo.
    echo Executing %%f ...

    psql ^
      -h %HOST% ^
      -p %PORT% ^
      -U %USER% ^
      -d %DB% ^
      -v ON_ERROR_STOP=1 ^
      -f "%%~dp0%%f"

    if errorlevel 1 goto ERROR
)

echo.
echo ========================================
echo DB Update and Verification Success
echo ========================================
pause
exit /b 0

:ERROR
echo.
echo ========================================
echo DB Update Failed
echo Check the first PostgreSQL error above.
echo ========================================
pause
exit /b 1
