BEGIN;

INSERT INTO public.tractor (
    vehicle_id,
    tractor_no,
    vehicle_structure,
    traffic_survey_class,
    axle_count,
    max_load_ton,
    gross_weight_ton,
    requires_weighing,
    special_transport,
    operation_status,
    updated_at
)
SELECT
    v.vehicle_id,
    v.tractor_no,
    COALESCE(NULLIF(TRIM(v.vehicle_structure), ''), 'TRACTOR'),
    v.traffic_survey_class,
    v.axle_count,
    v.max_load_ton,
    v.gross_weight_ton,
    COALESCE(v.requires_weighing, FALSE),
    COALESCE(v.special_transport, FALSE),
    CASE
        WHEN UPPER(TRIM(COALESCE(v.vehicle_status, ''))) IN (
            'IN_OPERATION', 'WORKING', '작업중', '운행중'
        ) THEN 'IN_OPERATION'
        WHEN UPPER(TRIM(COALESCE(v.vehicle_status, ''))) IN (
            'ASSIGNED', 'ALLOCATED', '배정', '배정완료'
        ) THEN 'ASSIGNED'
        WHEN UPPER(TRIM(COALESCE(v.vehicle_status, ''))) IN (
            'MAINTENANCE', 'REPAIR', '정비', '수리중'
        ) THEN 'MAINTENANCE'
        WHEN UPPER(TRIM(COALESCE(v.vehicle_status, ''))) IN (
            'SUSPENDED', 'DISABLED', '승인거절', '사용중지'
        ) THEN 'SUSPENDED'
        ELSE 'AVAILABLE'
    END,
    CURRENT_TIMESTAMP
FROM public.vehicle v
WHERE UPPER(TRIM(COALESCE(v.vehicle_type, ''))) = 'TRACTOR'
   OR TRIM(COALESCE(v.vehicle_type, '')) = '트랙터'
ON CONFLICT (vehicle_id) DO UPDATE
SET
    tractor_no = EXCLUDED.tractor_no,
    vehicle_structure = EXCLUDED.vehicle_structure,
    traffic_survey_class = EXCLUDED.traffic_survey_class,
    axle_count = EXCLUDED.axle_count,
    max_load_ton = EXCLUDED.max_load_ton,
    gross_weight_ton = EXCLUDED.gross_weight_ton,
    requires_weighing = EXCLUDED.requires_weighing,
    special_transport = EXCLUDED.special_transport,
    operation_status = EXCLUDED.operation_status,
    updated_at = CURRENT_TIMESTAMP;

COMMIT;
