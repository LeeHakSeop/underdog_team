BEGIN;

UPDATE public.vehicle
SET vehicle_type = 'TRACTOR'
WHERE TRIM(COALESCE(vehicle_type, '')) = '트랙터';

UPDATE public.vehicle
SET vehicle_type = 'TRAILER'
WHERE TRIM(COALESCE(vehicle_type, '')) = '트레일러';

UPDATE public.vehicle
SET vehicle_type = 'CARGO'
WHERE TRIM(COALESCE(vehicle_type, '')) = '카고';

COMMIT;
