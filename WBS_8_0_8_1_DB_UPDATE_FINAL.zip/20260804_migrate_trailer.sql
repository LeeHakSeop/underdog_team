BEGIN;

INSERT INTO public.trailer (
    vehicle_id,
    trailer_no,
    trailer_structure,
    traffic_survey_class,
    axle_count,
    max_load_ton,
    gross_weight_ton,
    requires_weighing,
    dangerous_goods_vehicle,
    reefer_vehicle,
    special_transport,
    connection_type,
    operation_status,
    updated_at
)
SELECT
    v.vehicle_id,
    v.plate_number,
    COALESCE(NULLIF(TRIM(v.vehicle_structure), ''), 'TRAILER'),
    v.traffic_survey_class,
    v.axle_count,
    v.max_load_ton,
    v.gross_weight_ton,
    COALESCE(v.requires_weighing, FALSE),
    FALSE,
    FALSE,
    COALESCE(v.special_transport, FALSE),
    v.trailer_connection_type,
    CASE
        WHEN UPPER(TRIM(COALESCE(v.vehicle_status, ''))) IN (
            'IN_OPERATION', 'WORKING', '작업중', '운행중'
        ) THEN 'IN_OPERATION'
        WHEN UPPER(TRIM(COALESCE(v.vehicle_status, ''))) IN (
            'ASSIGNED', 'ALLOCATED', '배정', '배정완료'
        ) THEN 'ASSIGNED'
        WHEN UPPER(TRIM(COALESCE(v.vehicle_status, ''))) IN (
            'MAINTENANCE', 'REPAIR', '정비', '수리중'
        ) THEN 'MAINTENANCE'
        WHEN UPPER(TRIM(COALESCE(v.vehicle_status, ''))) IN (
            'SUSPENDED', 'DISABLED', '승인거절', '사용중지'
        ) THEN 'SUSPENDED'
        ELSE 'AVAILABLE'
    END,
    CURRENT_TIMESTAMP
FROM public.vehicle v
WHERE UPPER(TRIM(COALESCE(v.vehicle_type, ''))) = 'TRAILER'
   OR TRIM(COALESCE(v.vehicle_type, '')) = '트레일러'
ON CONFLICT (vehicle_id) DO UPDATE
SET
    trailer_no = EXCLUDED.trailer_no,
    trailer_structure = EXCLUDED.trailer_structure,
    traffic_survey_class = EXCLUDED.traffic_survey_class,
    axle_count = EXCLUDED.axle_count,
    max_load_ton = EXCLUDED.max_load_ton,
    gross_weight_ton = EXCLUDED.gross_weight_ton,
    requires_weighing = EXCLUDED.requires_weighing,
    special_transport = EXCLUDED.special_transport,
    connection_type = EXCLUDED.connection_type,
    operation_status = EXCLUDED.operation_status,
    updated_at = CURRENT_TIMESTAMP;

COMMIT;
