BEGIN;

CREATE TABLE IF NOT EXISTS public.tractor
(
    tractor_id BIGSERIAL PRIMARY KEY,
    vehicle_id BIGINT NOT NULL UNIQUE,
    tractor_no VARCHAR(50),
    vehicle_structure VARCHAR(30),
    traffic_survey_class INTEGER,
    axle_count INTEGER,
    max_load_ton NUMERIC(7, 2),
    gross_weight_ton NUMERIC(7, 2),
    requires_weighing BOOLEAN NOT NULL DEFAULT FALSE,
    special_transport BOOLEAN NOT NULL DEFAULT FALSE,
    operation_status VARCHAR(30) NOT NULL DEFAULT 'AVAILABLE',
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_tractor_vehicle
        FOREIGN KEY (vehicle_id)
        REFERENCES public.vehicle (vehicle_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT ck_tractor_traffic_survey_class
        CHECK (
            traffic_survey_class IS NULL
            OR traffic_survey_class BETWEEN 1 AND 12
        ),

    CONSTRAINT ck_tractor_axle_count
        CHECK (
            axle_count IS NULL
            OR axle_count BETWEEN 1 AND 12
        ),

    CONSTRAINT ck_tractor_max_load_ton
        CHECK (
            max_load_ton IS NULL
            OR max_load_ton >= 0
        ),

    CONSTRAINT ck_tractor_gross_weight_ton
        CHECK (
            gross_weight_ton IS NULL
            OR gross_weight_ton >= 0
        ),

    CONSTRAINT ck_tractor_operation_status
        CHECK (
            operation_status IN (
                'AVAILABLE',
                'ASSIGNED',
                'IN_OPERATION',
                'MAINTENANCE',
                'SUSPENDED'
            )
        )
);

CREATE INDEX IF NOT EXISTS idx_tractor_vehicle_id
    ON public.tractor (vehicle_id);

CREATE INDEX IF NOT EXISTS idx_tractor_operation_status
    ON public.tractor (operation_status);

CREATE INDEX IF NOT EXISTS idx_tractor_traffic_survey_class
    ON public.tractor (traffic_survey_class);

COMMIT;
