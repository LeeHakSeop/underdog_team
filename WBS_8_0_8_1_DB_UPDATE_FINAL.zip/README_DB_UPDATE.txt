WBS 8.0 / 8.1 DB UPDATE PACKAGE
Date: 2026-08-04

[적용 내용]
1. tractor 테이블 생성
2. trailer 테이블 생성
3. vehicle_type 값 정규화
   - 트랙터 -> TRACTOR
   - 트레일러 -> TRAILER
   - 카고 -> CARGO
4. 기존 vehicle 트랙터 데이터 tractor 테이블로 이관
5. 기존 vehicle 트레일러 데이터 trailer 테이블로 이관
6. 적용 결과 검증 SQL 제공
7. 롤백 SQL 제공

[실행 방법]
1. PostgreSQL의 psql 명령이 PATH에 등록되어 있어야 합니다.
2. apply_db_update.bat을 더블클릭합니다.
3. PostgreSQL 비밀번호를 입력합니다.
4. 완료 후 검증 결과를 확인합니다.

[기본 접속 설정]
HOST=localhost
PORT=5432
USER=postgres
DB=portprj

환경이 다르면 apply_db_update.bat 상단 값을 수정하세요.

[실행 순서]
1. 20260804_create_tractor_table.sql
2. 20260804_create_trailer_table.sql
3. 20260804_normalize_vehicle_type.sql
4. 20260804_migrate_tractor.sql
5. 20260804_migrate_trailer.sql
6. 20260804_verify.sql

[정상 검증 기준]
- tractor_count = vehicle_tractor_count
- trailer_count = vehicle_trailer_count
- tractor_missing_count = 0
- trailer_missing_count = 0
- wrong_tractor_type_count = 0
- wrong_trailer_type_count = 0

[롤백]
rollback 폴더의 rollback_all.sql을 실행하면 tractor와 trailer 테이블을 제거합니다.
주의: 롤백하면 두 상세 테이블의 데이터가 삭제됩니다.

[재실행]
CREATE TABLE IF NOT EXISTS와 ON CONFLICT 구문을 사용하므로 반복 실행할 수 있습니다.
