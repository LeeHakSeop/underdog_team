const USER_KEY = 'portGateUser'
const ACCOUNT_KEY = 'portGateAccounts'

export const roleOptions = [
  { code: 'CARRIER', label: '운송사 담당자', home: '/carrier/dashboard' },
  { code: 'DRIVER', label: '화물 기사', home: '/driver/dashboard' },
  { code: 'ADMIN', label: '관리자', home: '/admin/main' },
]

const defaultAccounts = [
  {
    username: 'admin',
    password: '1234',
    roleCode: 'ADMIN',
    roleName: '관리자',
    status: 'APPROVED',
    displayName: '시스템 관리자',
  },
]

const readJson = (key, fallback) => {
  try {
    return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback))
  } catch {
    return fallback
  }
}

const writeJson = (key, value) => localStorage.setItem(key, JSON.stringify(value))

export const readCurrentUser = () => readJson(USER_KEY, null)
export const clearCurrentUser = () => localStorage.removeItem(USER_KEY)

export const readAccounts = () => {
  const accounts = readJson(ACCOUNT_KEY, [])
  if (!accounts.length) {
    writeJson(ACCOUNT_KEY, defaultAccounts)
    return defaultAccounts
  }
  return accounts
}

export const saveAccounts = (accounts) => writeJson(ACCOUNT_KEY, accounts)

export const findRole = (roleCode) => roleOptions.find((role) => role.code === roleCode) || roleOptions[0]

export const loginAccount = ({ username, password, roleCode }) => {
  const account = readAccounts().find(
    (item) => item.username === username && item.password === password && item.roleCode === roleCode,
  )

  if (!account) {
    throw new Error('아이디, 비밀번호, 역할을 다시 확인하세요.')
  }

  if (account.status !== 'APPROVED') {
    throw new Error('관리자 승인 후 로그인할 수 있습니다.')
  }

  const role = findRole(account.roleCode)
  const user = {
    username: account.username,
    roleCode: account.roleCode,
    roleName: role.label,
    displayName: account.displayName || account.username,
  }

  writeJson(USER_KEY, user)
  return { user, home: role.home }
}

export const registerAccount = (account) => {
  const accounts = readAccounts()
  const exists = accounts.some((item) => item.username === account.username)

  if (exists) {
    throw new Error('이미 사용 중인 아이디입니다.')
  }

  const newAccount = {
    ...account,
    roleName: findRole(account.roleCode).label,
    status: account.roleCode === 'ADMIN' ? 'APPROVED' : 'PENDING',
  }

  saveAccounts([...accounts, newAccount])
  return newAccount
}

export const updateAccountStatus = (username, status) => {
  const accounts = readAccounts().map((account) =>
    account.username === username ? { ...account, status } : account,
  )
  saveAccounts(accounts)
}
